<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lộ Trình Học 3</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
  
    <!-- Custom styles for this template -->
    <link href="css/agency.min.css" rel="stylesheet">
</head>
<body>

<!-- nav -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top " style="background-color:black; height: 60px" id="mainNav">
        <div class="container">
                <a class="navbar-brand js-scroll-trigger" href="index.php">English Center</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                  Menu
                  <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                  <ul class="navbar-nav text-uppercase ml-auto">
                    <li class="nav-item">
                      <a class="nav-link js-scroll-trigger" href="#dacdiem">
                        <h6>Đặc Điểm Lổi Bật</h6>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link js-scroll-trigger" href="#doituong">
                        <h6>Đối Tượng</h6>
                      </a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link js-scroll-trigger" href="#lotrinh">
                        <h6>Lộ Trình Học</h6>
                      </a>
                    </li>
                  </ul>
        </div>
        </div>
    </nav>

<!-- đac điểm -->
    <section class="bg-light page-section" id="dacdiem">
            <div class="container">
              <div class="row">
                <div class="col-lg-12 text-center">
                  <h2 class="section-heading text-uppercase text-danger">ĐIỂM NỔI BẬT CỦA KHÓA GIAO TIẾP VỚI NGƯỜI NƯỚC NGOÀI</h2>
                  <h3 class="section-subheading text-muted">English Center</h3>
                </div>
              </div>
              <div class="row">
                <div class="col-sm-3">
                  <div class="team-member">
                    <img class="mx-auto" src="img/lotrinhhoc/4.png" alt="">
                    <br>
                    <br>
                    <h5 style="color:red">ĐÁP ỨNG ĐÚNG NHU CẦU</h5>
                    <p class="text-muted">Đây là chương trình học duy nhất được xây dựng riêng theo nhu cầu và mục tiêu cụ thể của từng học viên khi tham gia học dựa trên nền tảng của lộ trình đào tạo Toàn Diện 4 Kĩ Năng được đầu tư nghiên cứu trong nhiều năm liền của Trung Tâm, nội dung học sẽ được điều chỉnh, thiết kế bổ sung nhằm giúp học viên tiến bộ nhanh nhất</p>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="team-member">
                    <img class="mx-auto" src="img/lotrinhhoc/5.png" alt="">
                    <br>
                    <br>
                    <h5 style="color:red">LINH HOẠT</h5>
                    <p class="text-muted">Khác với các lớp có lịch học và địa điểm cố định, với Tiếng Anh Theo Yêu Cầu học viên hoàn toàn chủ động trong việc lựa chọn lịch học và địa điểm sao cho phù hợp nhất. Thời gian được sắp xếp linh hoạt kể cả trong hoặc ngoài giờ hành chính, trong tuần hay cuối tuần</p>
                  </div>
                </div>
                <div class="col-sm-3">
                  <div class="team-member">
                    <img class="mx-auto" src="img/lotrinhhoc/6.png" alt="">
                    <br>
                    <br>
                    <h5 style="color:red">CHẤT LƯỢNG</h5>
                    <p class="text-muted">100% đội ngũ giáo viên có trình độ giảng dạy chuyên nghiệp, chu đáo, tận tâm và vô cùng nhiệt tình. Giáo viên có nhiều năm kinh nghiệm với phong cách giảng dạy lôi cuốn, luôn luôn thấu hiểu và sẵn sàng chia sẻ kinh nghiệp học tập cho học viên</p>
                  </div>
                </div>
                <div class="col-sm-3">
                    <div class="team-member">
                        <img class="mx-auto" src="img/lotrinhhoc/7.png" alt="">
                        <br>
                        <br>
                        <h5 style="color:red">TẬN TÌNH</h5>
                        <p class="text-muted">Chỉ có tại Jaxtina học viên sẽ được theo dõi, chăm sóc và hỗ trợ học hàng ngày nhằm tạo động lực học tiếng Anh và đảm bảo học viên khi tham gia khóa Tiếng Anh Theo Yêu cầu CHẮC CHẮN SẼ GIỎI sau khóa học</p>
                    </div>
                </div>
              </div>
            </div>
          </section>

<!-- đối tượng -->
          <section class="bg-light page-section" id="doituong">
                <div class="container">
                  <div class="row">
                    <div class="col-lg-12 text-center">
                      <h2 class="section-heading text-uppercase text-danger">Đối Tượng</h2>
                      <h3 class="section-subheading text-muted">English Center</h3>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="team-member">
                        <img class="mx-auto" src="img/lotrinhhoc/8.png" alt="">
                        <br>
                        <h4>Đối tượng phù hợp</h4>
                        <br>
                        <p class="text-muted">Cá nhân hoặc nhóm muốn học Tiếng Anh cấp tốc phù hợp với công việc của mình</p>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="team-member">
                        <img class="mx-auto rounded-circle" src="img/lotrinhhoc/9.png" alt="">
                        <br>
                          <h4>Thời gian học</h4>
                        <br>
                        <p class="text-muted">Trong hoặc ngoài giờ hành chính, tùy theo đặc điểm của học viên.</p>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="team-member">
                        <img class="mx-auto rounded-circle" src="img/lotrinhhoc/10.png" alt="">
                        <br>
                        <h4>Địa điểm học</h4>
                        <br>
                        <p class="text-muted">Tại địa điểm của học viên, hoặc tại các cơ sở của Trung Tâm.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
                    
              <section class="pricing py-5 bg-light page-section " id="lotrinh">
  <div class="container">
      <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading text-uppercase text-danger">Lộ Trình Học</h2>
            <h3 class="section-subheading text-muted">English Center</h3>
          </div>
        </div>
    <div class="row">
      <!-- cấp độ pre-s -->
      <div class="col-lg-4">
        <div class="card mb-5 mb-lg-0">
          <div class="card-body">
            
            <h5 class="card-title text-uppercase text-center" style ="color: red">CẤP ĐỘ PRE-S (12 buổi)</h5>
            <h6 class="card-price text-center"><span class="period">BỔ SUNG KIẾN THỨC NỀN TẢNG</span></h6>
            <hr>
            <ul class="fa-ul" style ="color: blue">
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Học từ vựng liên quan đến 7 topics thông dụng nhất</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Bổ sung ngữ pháp căn bản về thì và các mẫu câu</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Học cách tự giới thiệu bản thân và gia đình</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Học viết các đoạn văn khoảng 50 từ bằng tiếng Anh</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- cấp độ s -->
      <div class="col-lg-4">
        <div class="card mb-5 mb-lg-0">
          <div class="card-body">
            <h5 class="card-title text-uppercase text-center" style ="color: red">CẤP ĐỘ S (24 buổi)</h5>
            <h6 class="card-price text-center"><span class="period">CỦNG CỐ NỀN TẢNG</span></h6>
            <hr>
            <ul class="fa-ul" style ="color: blue">
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Tăng cường vốn từ vựng với 15 topics mới</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Nắm chắc các ngữ pháp nền và mẫu câu nâng cao</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Luyện phản xạ giao tiếp và phát âm qua các chủ đề quen thuộc</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Luyện nghe hiểu các đoạn hội thoại tốc độ vừa phải và đọc hiểu đoạn văn ngắn, đơn giản</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Học cách viết các đoạn văn khoảng 100 - 150 từ về nhiều chủ đề khác nhau</li>
            </ul>
          </div>
        </div>
      </div>
      <!-- cấp độ tc -->
      <div class="col-lg-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title  text-uppercase text-center" style ="color: red">CẤP ĐỘ TC (24 buổi)</h5>
            <h6 class="card-price text-center"><span class="period">TOÀN DIỆN 4 KỸ NĂNG</span></h6>
            <hr>
            <ul class="fa-ul" style ="color: blue">
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Mở rộng vốn từ vựng lên tới hơn 2000 từ</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Đa dạng chủ đề học từ cuộc sống thường nhật đến công việc</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Tự tin giao tiếp bằng tiếng anh với phát âm chuẩn và dùng đúng ngữ pháp</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Biết đưa ra ý kiến và phản biện bằng tiếng anh</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Nghe hiểu các bài thuyết trình của người bản ngữ</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Đọc hiểu các văn bản dài 450 - 500 từ</li>
              <li><span class="fa-li"><i class="fas fa-check"></i></span>Viết hoàn chỉnh các văn bản: email, đoạn văn dài 150 - 200 từ...</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</body>
</html>