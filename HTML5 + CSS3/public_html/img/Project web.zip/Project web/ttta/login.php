
<?php
session_start();
include 'Admin/connectdb.php';

function loginStudent($username, $password){
	global $dbh;
	$sql = "select mahs from userhs where username = :username and password = :password";
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);
	$statement->execute();
	$student = $statement->fetch();
	$statement->closeCursor();
	return $student;
}
function loginTeacher($username, $password){
	global $dbh;
	$sql = "select magv from usergv where username = :username and password = :password";
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);
	$statement->execute();
	$teacher = $statement->fetch();
	$statement->closeCursor();
	return $teacher;
}
function loginParent($username, $password){
	global $dbh;
	$sql = "select maph from userph where username = :username and password = :password";
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);
	$statement->execute();
	$parent = $statement->fetch();
	$statement->closeCursor();
	return $parent;
}
function loginAdmin($username, $password){
	if($username == "admin" && $password == "admin")
		return true;
	else
		return false;
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<!--Made with love by Mutiullah Samim -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="css/login.css">
</head>
<body>
	<div class="container">
		<div class="d-flex justify-content-center h-100" >
			<div class="card">
				<div class="card-header">
					<h3>Sign In</h3>
				</div>
				<div class="card-body">
					<form action="" method="POST">
						<div class="input-group form-group">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" name="username" class="form-control" placeholder="username">
						</div>
						<div class="input-group form-group">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<input type="password" name="password" class="form-control" placeholder="password">
						</div>
						<div class="form-group">
							<input type="submit" name="login" value="Login" class="btn float-right login_btn">
						</div>
					</form>

				</div>
				<div class="card-footer">
					<div class="d-flex justify-content-center links">
						<a href="index.php">Trang Chủ</a>
					</div>

				</div>
			</div>
		</div>
	</div>
</body>
</html>
<?php
if (isset($_POST['login'])) {

	$username = $_POST['username'];
	$password = $_POST['password'];

	$student = loginStudent($username, $password);
	$parent = loginParent($username, $password);
	$teacher = loginTeacher($username, $password);

	if(loginAdmin($username, $password)){
		$_SESSION['user_admin'] = $username;
		header("location: Admin/admin.php");
	}
	else if ($student['mahs'] != "") {
		$_SESSION['user_student'] = $username;
		header("location: index.php");
	}else if ($parent['maph'] != "") {
		$_SESSION['user_parent'] = $username;
		header("location: index.php");
	}else if ($teacher['magv'] != "") {
		$_SESSION['user_teacher'] = $username;
		header("location: index.php");
	}else{
		echo "<script>
		alert('Tài khoản hoặc mật khẩu không chính xác!');
		</script>";
	}
}
?>