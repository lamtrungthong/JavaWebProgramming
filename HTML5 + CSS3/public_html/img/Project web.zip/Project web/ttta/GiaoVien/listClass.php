<!DOCSTYPE html>
<?php 
ob_start();
session_start();
require '../Admin/connectdb.php';
require '../islogin.php';
require '../isStlogin.php';
require '../isParLogin.php';
require '../isTeachLogin.php';
?>

<?php 
function countSt($malop) {
	global $dbh;
	$query = 'SELECT count(malop) as dangky
	FROM hocsinh
	WHERE malop = :malop ' ;
	$statement = $dbh->prepare($query);
	$statement->bindValue(':malop', $malop);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 class
 $statement->closeCursor();
 return $result;
}
?>
<html>
<head>

	<title>Danh sách lớp</title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>English Center</title>
	<!-- Custom fonts for this template-->
	<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<!-- Bootstrap core CSS -->
	<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

	<!-- Custom fonts for this template -->
	<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
	<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
	<!-- Bootstrap core JavaScript -->
	<script src="../vendor/jquery/jquery.min.js"></script>
	<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Plugin JavaScript -->
	<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Contact form JavaScript -->
	<script src="../js/jqBootstrapValidation.js"></script>
	<script src="../js/contact_me.js"></script>

	<!-- Custom scripts for this template -->
	<script src="../js/agency.min.js"></script>

	<!-- Custom styles for this template -->
	<link href="../css/agency.min.css" rel="stylesheet">
	<link href="./css/style.css" rel="stylesheet">
</head>
<body id="page-top">
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top " style="background-color:black; height: 60px" id="mainNav">
		<div class="container">
			<a class="navbar-brand js-scroll-trigger" href="../index.php">English Center</a>
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				Menu
				<i class="fas fa-bars"></i>
			</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav text-uppercase ml-auto">
					<!--Profile  -->
					<?php
					if (isTeachlogin() == true) {
						$teacher = getNameTeach($_SESSION['user_teacher']);
						echo "<li class='nav-item dropdown no-arrow'>";
						echo "<a class='nav-link dropdown-toggle' href='#'' id='userDropdown' role='button' data-toggle='dropdown' aria-haspopup= true aria-expanded= false >";
						echo "<span class= 'mr-2 d-none d-lg-inline text-white-600 lg'>".$teacher['tengv'] ."</span>";
						echo "<img class='img-profile rounded-circle' src='../img/profile.png' width='20' height= 20 >
						</a>
						<div class= 'dropdown-menu dropdown-menu-right shadow animated--grow-in' aria-labelledby='userDropdown'>
						<a class= 'dropdown-item' href='Schedule.php'>
						<i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
						Lịch dạy
						</a>
						<a class= 'dropdown-item' href='listClass.php'>
						<i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
						Danh sách lơp
						</a>
						<a class='dropdown-item' href= '#' data-toggle= modal  data-target= '#logoutModal'>
						<i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-black-200'></i>
						Logout
						</a>
						</div>
						</li>"; 
					}
					else{
						echo "<li class='nav-item'>
						<a href='login.php'>
						<button type='button' class='btn btn-primary' style='margin-left:50px ;margin-top:5px'>Đăng nhập</button>
						</a>
						</li>";
					}

					?>
				</ul>
			</div>
		</div>
	</nav>
	<!-- Logout Modal-->
	<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
					<a class="btn btn-primary" href="../logout.php">Logout</a>
				</div>
			</div>
		</div>
	</div>
	<div id="slides" class="carousel slide" data-ride="carousel">
		<?php
		$sql = "select anh from quangcao";
		$statement = $dbh->prepare($sql);
		$statement->execute();
		$anhs = $statement->fetchAll();
		$statement->closeCursor();
		echo "<ul class='carousel-indicators'>";
		for($i = 0; $i< count($anhs) ; $i++) {    
			if($i == 0){
				echo "<li data-target= #slides data-slide-to=".$i." class= active></li>";
			}else{
				echo "<li data-target= #slides data-slide-to=". $i."></li>";
			}

		}
		echo "</ul>";

		?>
		<div class="carousel-inner">
			<?php
			for($i = 0; $i< count($anhs) ; $i++){
				if ($i == 0) {
					echo "<div class='carousel-item active' >";
					echo "<img src=../img/".$anhs[$i]['anh']." width = 100% height = 800px >";
					echo "</div>";
				}
				else {
					echo "<div class='carousel-item ' >";
					echo "<img src=../img/".$anhs[$i]['anh']." width = 100% height = 800px >";
					echo "</div>";
				}
			}
			?>
		</div>
	</div>
	<div>

		<?php
		$sql = "select * from lophoc where magv = :magv";
		$statement = $dbh->prepare($sql);
		$statement->bindValue(':magv', $_SESSION['user_teacher']);
		$statement->execute();
		$list = $statement->fetchAll();
		$statement->closeCursor();

		try {
			$page = "<h1 class='display-4 my-4 text-info'>Danh sách lớp</h1>";
			$page .= "<table class='table table-striped' id='users' style='width: 100%;'>";
			$page .="<thead >";
			$page .="<tr id='list-header'>";
			$page .="<th scope='col'>STT</th>";
			$page .="<th scope='col'>Mã lớp</th>";
			$page .="<th scope='col'>Tên lớp</th>";
			$page .="<th scope='col'>Đăng ký</th>";
			$page .="<th scope='col'>Điểm danh</th>";
			$page .="</tr>";
			$page .="</thead>";  
			$page .="<tbody>";  
			$stt = 1;    
			foreach ($list as $class) {
				$sum = countSt($class['malop']);
				$page .= '<td>' . $stt . '</td>';
				$page .= '<td>' . $class['malop'] . '</td>';
				$page .= '<td>' . $class['tenlop'] . '</td>';
				$page .= '<td>' . $sum['dangky'] . '</td>';
				$page .= "<td><a href=\"listStudent.php?malop=".$class['malop']."\">Điểm danh</a></td>";
				$page .= '</tr>';
				$stt++;
			}
			$page .="</tbody>";
			$page .= '</table>';
			echo $page;
		} catch (PDOException $e) {
			print_r($e->getMessage());
		}
		$dbh=null;
		ob_end_flush();
		?>

	</div>
	<section class="page-section background-color: white">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8 text-center">
					<h2 class="mt-0">ENGLISH CENTER!</h2>
					<hr class="divider my-4">
					<b class="text-muted mb-5">Cơ quan chủ quản: Học viện Kỹ thuật Mật mã</b>
					<p class="text-muted mb-5">Giám Đốc Trung Tâm: Lê Đức Thuận.</p>
					<p class="text-muted mb-5">Địa chỉ: 141 đường Chiến Thắng, Tân Triều, Thanh Trì, Hà Nội.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
					<i class="fas fa-phone fa-3x mb-3 text-muted"></i>
					<div>0962275585</div>
				</div>
				<div class="col-lg-4 mr-auto text-center">
					<i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
					<!-- Make sure to change the email address in anchor text AND the link below! -->
					<div>nnkma@gmail.com</div>
				</div>
				<div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
					<i class="fab fa-facebook-f fa-3x mb-3 text-muted"></i>
					<a class="d-block" href="https://www.facebook.com/kma.trungtamngoaingu">Facebook</a>
				</div>

			</div>
		</section>
	</body>
	</html>