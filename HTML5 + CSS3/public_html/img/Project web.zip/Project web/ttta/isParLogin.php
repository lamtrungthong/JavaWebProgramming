<!DOCSTYPE html>
<html>

<body>
<?php
include "Admin/connectdb.php";
function isParlogin(){
	
	if (isset($_SESSION['user_parent'])) {
		
		return true;
	} else 
		return false;
}
function getNamePar($maph){
	global $dbh;
	$query = 'SELECT tenph FROM phuhuynh  WHERE maph = :maph';
		$statement = $dbh->prepare($query);
		$statement->bindValue(':maph', $maph);
		$statement->execute();
		$parent = $statement->fetch(); 
		$statement->closeCursor();
		return $parent;
}
?>
</body>
</html>