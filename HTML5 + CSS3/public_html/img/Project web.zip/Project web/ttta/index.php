<?php 
session_start();
require 'islogin.php';
require 'isStlogin.php';
require 'isParLogin.php';
require 'isTeachLogin.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>English Center</title>
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>

  <!-- Custom styles for this template -->
  <link href="css/agency.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top">English Center</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav text-uppercase ml-auto">
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#advantages">
              <h6>Về Trung Tâm</h6>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#course">
              <h6>Khóa Học và Lịch Khai Giảng</h6>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#portfolio">
              <h6>Đội Ngũ Giáo Viên</h6>
            </a>
          </li>
          
          <!--Profile  -->
          <?php
          if (isStlogin() == true) {
            $student = getNameSt($_SESSION['user_student']);
            echo "<li class='nav-item dropdown no-arrow'>";
            echo "<a class='nav-link dropdown-toggle' href='#'' id='userDropdown' role='button' data-toggle='dropdown' aria-haspopup= true aria-expanded= false >";
            echo "<span class= 'mr-2 d-none d-lg-inline text-white-600 lg'>".$student['tenhs'] ."</span>";
            echo "<img class='img-profile rounded-circle' src='./img/profile.png' width='20' height= '20' >
            </a>
            <div class= 'dropdown-menu dropdown-menu-right shadow animated--grow-in' aria-labelledby='userDropdown'>
            <a class= 'dropdown-item' href='HocSinh/profile.php'>
            <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
            Profile
            </a>
            <a class='dropdown-item' href= '#' data-toggle= modal  data-target= '#logoutModal'>
            <i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-black-200'></i>
            Logout
            </a>
            </div>
            </li>"; 
          }else if (isParlogin() == true) {
           $parent = getNamePar($_SESSION['user_parent']);
           echo "<li class='nav-item dropdown no-arrow'>";
           echo "<a class='nav-link dropdown-toggle' href='#'' id='userDropdown' role='button' data-toggle='dropdown' aria-haspopup= true aria-expanded= false >";
           echo "<span class= 'mr-2 d-none d-lg-inline text-white-600 lg'>".$parent['tenph'] ."</span>";
           echo "<img class='img-profile rounded-circle' src='./img/profile.png' width='20' height= 20 >
           </a>
           <div class= 'dropdown-menu dropdown-menu-right shadow animated--grow-in' aria-labelledby='userDropdown'>
           <a class= 'dropdown-item' href='PhuHuynh/profile.php'>
           <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
           Thông tin cá nhân
           </a>
           <a class= 'dropdown-item' href='PhuHuynh/profileSt.php'>
           <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
           Thông tin học sinh
           </a>
           
           <a class= 'dropdown-item' href='PhuHuynh/fees.php'>
           <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
           Thông tin học phí
           </a>
           <a class='dropdown-item' href= '#' data-toggle= modal  data-target= '#logoutModal'>
           <i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-black-200'></i>
           Logout
           </a>
           </div>
           </li>"; 
         }else if (isTeachlogin() == true) {
           $teacher = getNameTeach($_SESSION['user_teacher']);
           echo "<li class='nav-item dropdown no-arrow'>";
           echo "<a class='nav-link dropdown-toggle' href='#'' id='userDropdown' role='button' data-toggle='dropdown' aria-haspopup= true aria-expanded= false >";
           echo "<span class= 'mr-2 d-none d-lg-inline text-white-600 lg'>".$teacher['tengv'] ."</span>";
           echo "<img class='img-profile rounded-circle' src='./img/profile.png' width='20' height= 20 >
           </a>
           <div class= 'dropdown-menu dropdown-menu-right shadow animated--grow-in' aria-labelledby='userDropdown'>
           <a class= 'dropdown-item' href='GiaoVien/Schedule.php'>
           <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
           Lịch dạy
           </a>
           <a class= 'dropdown-item' href='GiaoVien/listClass.php'>
           <i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
           Danh sách lơp
           </a>
           <a class='dropdown-item' href= '#' data-toggle= modal  data-target= '#logoutModal'>
           <i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-black-200'></i>
           Logout
           </a>
           </div>
           </li>"; 
         }
         else{
           echo "<li class='nav-item'>
           <a href='login.php'>
           <button type='button' class='btn btn-primary' style='margin-left:50px ;margin-top:5px'>Đăng nhập</button>
           </a>
           </li>";
         }

         ?>
       </ul>
     </div>
   </div>
 </nav>
 <!-- Logout Modal-->
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>

<!-- Header -->
<div id="slides" class="carousel slide" data-ride="carousel">
  <?php
  $sql = "select anh from quangcao";
  $statement = $dbh->prepare($sql);
  $statement->execute();
  $anhs = $statement->fetchAll();
  $statement->closeCursor();
  echo "<ul class='carousel-indicators'>";
  for($i = 0; $i< count($anhs) ; $i++) {    
    if($i == 0){
      echo "<li data-target= #slides data-slide-to=".$i." class= active></li>";
    }else{
      echo "<li data-target= #slides data-slide-to=". $i."></li>";
    }

  }
  echo "</ul>";

  ?>
  <div class="carousel-inner">
    <?php
    for($i = 0; $i< count($anhs) ; $i++){
      if ($i == 0) {
        echo "<div class='carousel-item active' >";
        echo "<img src=./img/".$anhs[$i]['anh']." width = 100% height = 800px >";
        ?>
        <div class='carousel-caption'>
       <h1 style ="margin-top: 30%" >Welcome To</h1>
        <h1 class='display-2'>English Center</h1>
        <a class='btn btn-primary btn-lg' href='register.php'>Đăng Ký Học</a>
        </div>
        </div>
        <?php
      }
      else {
        echo "<div class='carousel-item ' >";
        echo "<img src=./img/".$anhs[$i]['anh']." width = 100% height = 800px >";
        echo "</div>";
      }

    }

    ?>
  </div>
</div>

<!-- ưu điểm -->
<section class="bg-light page-section" id="advantages">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase text-danger">Ưu điểm vượt trội</h2>
        <h3 class="section-subheading text-muted">English Center</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/team/số1.jpg" alt="">
          <h4>LÀ TRUNG TÂM ĐẦU TIÊN TẠI VIỆT NAM</h4>
          <p class="text-muted"> Đào tạo Tiếng Anh Toàn Diện 4 Kỹ Năng cho người lớn ứng dụng cho học tập và làm việc</p>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/team/phương pháp học.jpg" alt="">
          <h4>PHƯƠNG PHÁP HỌC FLIPPED LEARNING</h4>
          <p class="text-muted">Phương pháp Flipped Learning được 80% các trường đại học hàng đầu thế giới áp dụng vào chương trình đào tạo</p>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/team/cam kết.png" alt="">
          <h4>ENGLISH CENTER-CAM KẾT CHẤT LƯỢNG</h4>
          <p class="text-muted">- Khóa học tiếng anh giao tiếp giọng Mỹ tại Jaxtina cam kết đầu ra bằng hợp đồng đào tạo</p>
          <p class="text-muted">- Hoàn lại trọn đời hoàn toàn miễn phí bất cứ khi nào tiếng Anh bị mai một</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- cac khoa học -->
<section class="bg-light page-section" id="course">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase text-danger">Khóa Học Và Lịch Khai Giảng</h2>
        <h3 class="section-subheading text-muted">English Center</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/lotrinhhoc/1.png" alt="">
          <a class="text-success" href="course.php">
            <h4>KHÓA TIẾNG ANH CHO NGƯỜI MỚI BẮT ĐẦU</h4>
          </a>
          <ul>
            <li>Học lại toàn bộ các kiến thức nền tảng tiếng Anh</li>
            <li>Giao tiếp được những tình huống đơn giản</li>
            <li>Trở nên yêu thích và biết cách tự học</li>
            <li>Bảo hành kết quả đầu ra trọn đời</li>
          </ul>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/lotrinhhoc/2.png" alt="">
          <a class="text-success" href="course 2.php">
            <h4>KHÓA TIẾNG ANH TOÀN DIỆN 4 KỸ NĂNG</h4>
          </a>
          <ul>
            <li>Nghe Nói Đọc Viết tiếng Anh thành thạo</li>
            <li>Tự tin giao tiếp với người nước ngoài</li>
            <li>Dễ dàng làm việc trong môi trường quốc tế</li>
            <li>Bảo hành kết quả đầu ra trọn đời</li>
          </ul>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="team-member">
          <img class="mx-auto rounded-circle" src="img/lotrinhhoc/3.png" alt="">
          <a class="text-success" href="course 3.php">
            <h4>KHÓA GIAO TIẾP VỚI NGƯỜI NƯỚC NGOÀI</h4>
          </a>
          <ul class="">
            <li>Phát âm đúng chuẩn quốc tế</li>
            <li>Tự tin giao tiếp với người nước ngoài</li>
            <li>Nghe và giao tiếp tốt với người nước ngoài</li>
            <li>Bảo kết đảm bảo kết quả đầu ra</li>
          </ul>
        </div>
      </div>
      <div class="container">
        <div class="row justify-content-center align-items-center">
          <a class="btn btn-success btn-xl text-uppercase js-scroll-trigger" href="schedule.php">Lịch Khai Giảng</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- giao viên -->
<section class="bg-light page-section" id="portfolio">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase text-danger">Thông Tin Giáo Viên</h2>
        <h3 class="section-subheading text-muted">English Center</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal1">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/cogiao1.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Irene</h4>
          <p class="text-muted">Cố Vấn Đào Tạo</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal2">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/cogiao2.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Minh Nghi</h4>
          <p class="text-muted">Giảng Viên</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal3">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/cogiao3.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Jang Nana</h4>
          <p class="text-muted">Giảng Viên</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal4">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/thaygiao.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Chris Evans</h4>
          <p class="text-muted">Giảng Viên</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal5">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/thaygiao2.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Hải Dương</h4>
          <p class="text-muted">Giảng Viên</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 portfolio-item">
        <a class="portfolio-link" data-toggle="modal" href="#portfolioModal6">
          <div class="portfolio-hover">
            <div class="portfolio-hover-content">
              <i class="fas fa-plus fa-3x"></i>
            </div>
          </div>
          <img class="img-fluid" src="img/portfolio/cogiao4.jpg" alt="">
        </a>
        <div class="portfolio-caption">
          <h4>Ribi Sachi</h4>
          <p class="text-muted">Giảng Viên</p>
        </div>
      </div>
    </div>
  </div>
</section>



<!-- nhận xét -->
<section class="page-section" id="about">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-heading text-uppercase text-danger">Cảm Nhận của học viên</h2>
        <h3 class="section-subheading text-muted">English Center</h3>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <ul class="timeline">
          <li>
            <div class="timeline-image">
              <img class="rounded-circle img-fluid" src="img/hocvien/1.jpg" alt="">
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <h4>KHÓA 2017-2018</h4>
                <h4 class="subheading">Trân Mai Anh</h4>
              </div>
              <div class="timeline-body">
                <p class="text-muted">
                  "Em thật sự bất ngờ với sự thật tâm và nhiệt tình của giáo viên,
                  care và các anh chị viên nói chung tại Trung Tâm.
                  Rất chu đáo và tận tâm với học viên.
                  Em cảm thấy rất hài lòng và vui vì đã lựa chọn Trung Tâm là nơi học tập và nâng cao khả năng của mình. !"
                </p>
              </div>
            </div>
          </li>
          <li class="timeline-inverted">
            <div class="timeline-image">
              <img class="rounded-circle img-fluid" src="img/hocvien/2.jpg" alt="">
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <h4>KHÓA 2015-2016</h4>
                <h4 class="subheading">Mai Thúy Hồng</h4>
              </div>
              <div class="timeline-body">
                <p class="text-muted">
                  "Mình thực sự thích cách dạy của giáo viên tại Trung Tâm,
                  cô giáo nói tiếng Anh hay, giảng dạy nhiệt tình.
                  Mới đầu trình độ của mình còn rất kém,
                  nhưng khi tham gia khóa học này mình cảm thấy trình độ tiếng Anh của mình tiến bộ lên rất nhiều,
                  như có thể dịch được một đoạn văn dài, phát âm tiến bộ lên được nhiều so với lúc trước !"
                </p>
              </div>
            </div>
          </li>
          <li>
            <div class="timeline-image">
              <img class="rounded-circle img-fluid" src="img/hocvien/3.jpg" alt="">
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <h4>KHÓA 2016-2017</h4>
                <h4 class="subheading">Phạm Thùy Linh</h4>
              </div>
              <div class="timeline-body">
                <p class="text-muted">
                  “Trước đây mình rất dốt tiếng Anh,
                  chỉ học qua ngữ pháp để đối phó thi cử trên lớp chứ không bao giờ động đến kỹ năng Nghe,
                  Viết và Nói. Khi tham gia một khoá tiếng Anh tổng quát ở Trung Tâm,
                  mình đã thay đổi hoàn toàn suy nghĩ và đó thời điểm mình bắt đầu thấy hoá ra thực sự thích học và học được tiếng Anh. !”
                </p>
              </div>
            </div>
          </li>
          <li class="timeline-inverted">
            <div class="timeline-image">
              <img class="rounded-circle img-fluid" src="img/hocvien/4.jpg" alt="">
            </div>
            <div class="timeline-panel">
              <div class="timeline-heading">
                <h4>KHÓA 2017-2018</h4>
                <h4 class="subheading">Bùi Văn Tuấn</h4>
              </div>
              <div class="timeline-body">
                <p class="text-muted">
                  "Tôi đã tham gia nhiều khóa học ở nhiều trung tâm khác nhau nhưng đều bỏ giữa chừng.
                  Trung Tâm là nơi đầu tiên tôi có cảm giác mình có hứng thú theo học.
                  Sau mỗi buổi làm việc vất vả, tôi lại đến trung tâm để học.
                  Đó cũng là lúc tôi cảm thấy thư giãn và thoải mái nhất !. "
                </p>
              </div>
            </div>
          </li>
          <li class="timeline-inverted">
            <div class="timeline-image">
              <h4>Your comment
                <br>will help us
                <br>improve!</h4>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>


  <!-- Contact -->
  <section class="page-section background-color: white">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8 text-center">
          <h2 class="mt-0">ENGLISH CENTER!</h2>
          <hr class="divider my-4">
          <b class="text-muted mb-5">Cơ quan chủ quản: Học viện Kỹ thuật Mật mã</b>
          <p class="text-muted mb-5">Giám Đốc Trung Tâm: Lê Đức Thuận.</p>
          <p class="text-muted mb-5">Địa chỉ: 141 đường Chiến Thắng, Tân Triều, Thanh Trì, Hà Nội.</p>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
          <div>0999999999</div>
        </div>
        <div class="col-lg-4 mr-auto text-center">
          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
          <!-- Make sure to change the email address in anchor text AND the link below! -->
          <div>nnkma@gmail.com</div>
        </div>
        <div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
          <i class="fab fa-facebook-f fa-3x mb-3 text-muted"></i>
          <a class="d-block" href="https://www.facebook.com/kma.trungtamngoaingu">Facebook</a>
        </div>

      </div>
    </section>

    <!-- Portfolio Modals -->

    <!-- Modal 1 -->
    <div class="portfolio-modal modal fade" id="portfolioModal1" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/cogiao1.jpg" alt="">
                  <p>Hơn 5 năm kinh nghiệm giảng dạy tiếng Anh tại Việt Nam và Anh, luôn được học viên yêu quý bởi cách giảng dạy lôi cuốn và hấp dẫn...Tác giả cuốn sách ‘Hacking your English speaking – Luyện nói tiếng Anh đột phá” nằm trong TOP sách tiếng Anh bán chạy nhất năm 2018</p>
                  <ul class="list-inline">
                    <li>Họ Tên: Bùi Trụ Hiện</li>
                    <li>Tuổi: 24 tuổi </li>
                    <li>Học Vấn: Tốt nghiệp Thạc sĩ xuất sắc tại Nottingham – Anh Quốc</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2 -->
    <div class="portfolio-modal modal fade" id="portfolioModal2" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/cogiao2.jpg" alt="">
                  <p>Hơn 3 năm kinh nghiệm giảng dạy tiếng Anh...Cô là người có chuyên môn rất sâu, cách giảng dạy nhiệt tình và rất lôi cuốn</p>
                  <ul class="list-inline">
                    <li>Họ Tên: Trần Nguyễn Minh Nghi</li>
                    <li>Tuổi : 23 tuổi</li>
                    <li>Học Vấn: Tốt nghiệp Đại học Sư phạm ngoại ngữ Hà Nội, học chuyên sâu giảng dạy 2 năm tại New Hampshire University (Mỹ) và đạt chứng chỉ TEFL</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 3 -->
    <div class="portfolio-modal modal fade" id="portfolioModal3" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/cogiao3.jpg" alt="">
                  <p>Hơn 3 năm kinh nghiệm giảng dạy tiếng Anh...Là một giảng viên có chuyên một cực tốt và siêu nhiệt tình với học viên...Ngoài giảng dạy, cô còn có khả năng nghiên cứu học thuật, cô đã là tác giả của nhiều cuốn sách, chương trình giảng dạy tiếng Anh cho một số trung tâm, trường học tại Hà Nội

                  </p>
                  <ul class="list-inline">
                    <li>Họ Tên: Jang Nana</li>
                    <li>Tuổi : 32 tuổi</li>
                    <li>Học Vấn: Tốt nghiệp xuất sắc tại Đại Học Ngoại Thương, Thạc sĩ tại Plymouth University (Anh)</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 4 -->
    <div class="portfolio-modal modal fade" id="portfolioModal4" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/thaygiao.jpg" alt="">
                  <p>Là Người Mỹ, hiện đang sinh sống và làm việc tại Việt Nam...hơn 5 năm kinh nghiệp giảng dạy... ngoài ra thầy còn đóng rất nhiều phim bom tấn :)))</p>
                  <ul class="list-inline">
                    <li>Họ Tên: Chris Evans</li>
                    <li>Tuổi : 28 tuổi</li>
                    <li>Học vấn : Thạc sỹ. Từng tốt nghiệp trường đại học danh tiếng nhất nước Mỹ</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 5 -->
    <div class="portfolio-modal modal fade" id="portfolioModal5" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/thaygiao2.jpg" alt="">
                  <p>Phong cách giảng dạy thực tế giúp học viên hiểu bài luôn, sử dụng được luôn và cảm nhận được tiến độ của bản thân qua từng buổi học, tuần học chứ không cần đợi tới các buổi test hàng tháng...Đặc biệt thầy Bình luôn áp dụng công nghệ vào chương trình giảng dạy: phân phối và quản lý tiến độ để tạo môi trường học và thực hành tiếng anh hàng ngày cho học viên</p>
                  <ul class="list-inline">
                    <li>Họ Tên : Lưu Hoà Bình</li>
                    <li>Tuổi : 24 tuổi</li>
                    <li>Học Vấn: Được tuyển thẳng vào khoa Kinh tế đối ngoại, ĐH Ngoại Thương, Hà Nội.“Cao thủ” IELTS 8.5 ( Listening và Reading đạt 9.0)</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 6 -->
    <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="close-modal" data-dismiss="modal">
            <div class="lr">
              <div class="rl"></div>
            </div>
          </div>
          <div class="container">
            <div class="row">
              <div class="col-lg-8 mx-auto">
                <div class="modal-body">
                  <!-- Project Details Go Here -->
                  <h2 class="text-uppercase">Thông Tin Cơ Bản</h2>
                  <p class="item-intro text-muted">English Center.</p>
                  <img class="img-fluid d-block mx-auto" src="img/portfolio/cogiao4.jpg" alt="">
                  <p>Hơn 3 năm kinh nghiệm giảng dạy tiếng Anh</p>
                  <ul class="list-inline">
                    <li>Họ Tên : Nguyễn Thị Thủy</li>
                    <li>Tuổi : 26 tuổi</li>
                    <li>Học vấn: Tốt nghiệp loại Giỏi tại Đại học Ngoại Thương.IELTS 7.5, Giải nhất cuộc thi tiếng Anh tại quận Hai Bà Trưng, Hà Nội</li>
                  </ul>
                  <button class="btn btn-primary" data-dismiss="modal" type="button">
                    <i class="fas fa-times"></i>
                  Đóng</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/agency.min.js"></script>

  </body>

  </html>
