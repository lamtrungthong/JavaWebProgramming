<!DOCSTYPE html>
<html>

<body>
<?php
function islogin(){
	
	if (isset($_SESSION['user_admin'])) {
		return true;
	} else 
		return false;
}
?>
</body>
</html>