<!DOCSTYPE html>
<html>
<?php 
session_start();
require 'islogin.php';
require 'isStlogin.php';
require 'isParLogin.php';
require 'isTeachLogin.php';
?>

<body>
	<?php
	if (islogin() == true) {
		echo "<h2>Welcome " . $_SESSION['user_admin'] . "</h2>";
		echo "<a href=Admin/manage.php>Quản lý nhân sự</a>";
		echo "<br/>";
		echo "<a href=Admin/manageAdvertise.php >Quảng cáo</a>";
		echo "<br/>";
		echo "<a href=logout.php>Đăng xuất</a>";
		echo "<br/>";
		echo "Today is " . date("d/m/y");
	} else if(isStlogin() == true) {
		$student = getNameSt($_SESSION['user_student']);
		echo "<h2>Welcome " . $student['tenhs'] . "</h2>";
		echo "<a href=HocSinh/profile.php>Thông tin</a><br>";
		echo "<a href=logout.php>Đăng xuất</a>";
		echo "<br/>";
	} else if(isParlogin() == true) {
		$parent = getNamePar($_SESSION['user_parent']);
		echo "<h2>Welcome " . $parent['tenph'] . "</h2>";
		echo "<a href=PhuHuynh/profileSt.php>Thông tin học sinh</a><br>";
		echo "<a href=PhuHuynh/fees.php>Thông tin học phí</a><br>";
		echo "<a href=logout.php>Đăng xuất</a>";
		echo "<br/>";
	} else if(isTeachlogin() == true) {
		$teacher = getNameTeach($_SESSION['user_teacher']);
		echo "<h2>Welcome " . $teacher['tengv'] . "</h2>";
		echo "<a href=GiaoVien/Schedule.php>Lịch dạy</a>";
		echo "<br/>";
		echo "<a href=GiaoVien/listClass.php>Danh sách lớp</a>";
		echo "<br/>";
		echo "<a href=logout.php>Đăng xuất</a>";
		echo "<br/>";
	}else {
		echo "<h3>Bạn chưa đăng nhập</h3>";
		echo "<a href=login.php>Click vào đây để đăng nhập</a>";
	}
	?>
</body>
</html>