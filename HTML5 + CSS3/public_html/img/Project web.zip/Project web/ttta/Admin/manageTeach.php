<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
</head>
<body>
	<a href = "QLGV/listTeacher.php" > Thông tin giáo viên </a><br>
	<a href = "QLGV/manageSal.php" > Lương giáo viên </a>
</body>
</html>