<!DOCSTYPE html>
<html>
<?php session_start(); ?>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body>
	<?php
	if (isset($_SESSION['user_admin'])) {
		echo "<h2>Welcome " . $_SESSION['user_admin'] . "</h2>";

		echo "<a href=QLLop/listClass.php>Quản lý lớp học</a>";
		echo "<br/>";
		
		echo "<a href=QLHS/listStudent.php>Quản lý học sinh</a>";
		echo "<br/>";

		echo "<a href=manageTeach.php>Quản lý giáo viên</a>";
		echo "<br/>";
		
		echo "<a href=# >Thống kê</a>";
		echo "<br/>";

		
		
		echo "Today is " . date("d/m/y");
	} else {
		echo "<h3>Bạn chưa đăng nhập</h3>";
		echo "<a href=../login.php>Click vào đây để đăng nhập</a>";
	}
	?>
</body>
</html>