<!DOCSTYPE html>
<?php 
ob_start();
session_start();
require '../connectdb.php';
require '../../islogin.php';
require 'functionsClass.php';
?>
<?php 
	//lấy ra các tên lớp có trong trung tâm
$query = 'SELECT distinct malop, tenlop FROM lophoc';
$statement = $dbh->prepare($query);
	$ch = $statement->execute(); //ch = true or false
	if (!$ch) {
		print_r($statement->errorInfo());
		exit();
	}
	$classes = $statement->fetchAll(); //lấy ra tất cả lop 
	$statement->closeCursor();
	?>
	<?php 
	//lấy ra các khóa có trong trung tâm
	$sql = "select * from khoa";
	$statement = $dbh->prepare($sql);
	$statement->execute();
	$khoa = $statement->fetchAll();
	$statement->closeCursor();
	?>
	<head>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Danh sách lớp học</title>

		<!-- Custom fonts for this template-->
		<link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

		<!-- Custom styles for this template-->
		<link href="../../css/sb-admin-2.min.css" rel="stylesheet">

		<style type="text/css">
			@import url('https://fonts.googleapis.com/css?family=Raleway');
			html, body {
				width: 100%;
				height: 100%;
				font-family: 'Raleway';
				font-size: 16px;	
				font-weight: bold;
			}
		</style>
	</head>
	<body id="page-top">

		<!-- Page Wrapper -->
		<div id="wrapper">

			<!-- Sidebar -->
			<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

				<!-- Sidebar - Brand -->
				<a class="sidebar-brand d-flex align-items-center justify-content-center" href="../admin.php">
					<div class="sidebar-brand-icon rotate-n-15">
						<i class="fas fa-laugh-wink"></i>
					</div>
					<div class="sidebar-brand-text mx-3">Hi Admin!</div>
				</a>

				<!-- Divider -->
				<hr class="sidebar-divider my-0">

				<!-- Nav Item - Dashboard -->
				<li class="nav-item active">
					<a class="nav-link" href="">
						<i class="fas fa-fw fa-tachometer-alt"></i>
						<span>Menu</span></a>
					</li>

					<!-- Divider -->
					<hr class="sidebar-divider">

					<!-- Heading -->
      <!-- <div class="sidebar-heading">
        Interface
    </div> -->

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
    		<i class="fas"></i>
    		<span>Giáo Viên</span>
    	</a>
    	<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="../QLGV/listTeacher.php">Thông tin Giáo Viên</a>
    			<a class="collapse-item" href="../QLGV/manageSal.php">Lương Giáo Viên</a>
    		</div>
    	</div>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
    		<i class="fas"></i>
    		<span>Học Viên</span>
    	</a>
    	<div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="../QLHS/listStudent.php">Thông tin học viên</a>
    			<a class="collapse-item" href="../QLPH/listParent.php">Thông tin phụ huynh</a>
    			<a class="collapse-item" href="../manageFee.php">Thông tin học phi</a>
    		</div>
    	</div>
    </li>

    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapselops" aria-expanded="true" aria-controls="collapsePages">
    		<i class="fas"></i>
    		<span>Lớp Học</span>
    	</a>
    	<div id="collapselops" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="listClass.php">Thông tin lớp học</a>
    		</div>
    	</div>
    </li>
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
    	<button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

	<!-- Main Content -->
	<div id="content">

		<!-- Topbar -->
		<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

			<!-- Sidebar Toggle (Topbar) -->
			<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
				<i class="fa fa-bars"></i>
			</button>

			<!-- Topbar Search -->
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
				<div class="input-group">
					<input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
					<div class="input-group-append">
						<button class="btn btn-primary" type="button">
							<i class="fas fa-search fa-sm"></i>
						</button>
					</div>
				</div>
			</form>

			<!-- Topbar Navbar -->
			<ul class="navbar-nav ml-auto">

				<!-- Nav Item - Search Dropdown (Visible Only XS) -->
				<li class="nav-item dropdown no-arrow d-sm-none">
					<a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-search fa-fw"></i>
					</a>
					<!-- Dropdown - Messages -->
					<div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
						<form class="form-inline mr-auto w-100 navbar-search">
							<div class="input-group">
								<input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
								<div class="input-group-append">
									<button class="btn btn-primary" type="button">
										<i class="fas fa-search fa-sm"></i>
									</button>
								</div>
							</div>
						</form>
					</div>
				</li>


				<div class="topbar-divider d-none d-sm-block"></div>

				<!-- Nav Item - User Information -->
				<li class="nav-item dropdown no-arrow">
					<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
						<img class="img-profile rounded-circle" src="../../img/profile.png">
					</a>
					<!-- Dropdown - User Information -->
					<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
						<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
							<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
							Logout
						</a>
					</div>
				</li>

			</ul>

		</nav>
		<div class="container-fluid">
			<div class="table-sm">
				<form action = "" method = "post">
					<table class="table-striped"  border=0 width=50%>
						<a class='btn btn-primary btn-sm' href='addClass.php'>Mở lớp</a>
						<tr bgcolor=#ccffcc >
							<th>Lọc </th>
							<th>
								<select name = "namhoc">
									<option value = "" > --Năm học-- </option>
									<option value = "2019" > 2019 </option>
									<option value = "2020" > 2020 </option>
									<option value = "2020" > 2021 </option>
								</select>
							</th>
							<th>
								<select name = "quy">
									<option value = "" > --Quý-- </option>
									<option value = "1" > 1 </option>
									<option value = "2" > 2 </option>
									<option value = "3" > 3 </option>
									<option value = "4" > 4 </option>
								</select>
							</th>
							<th>
								<select name = "khoa">
									<option value = "" > --Khóa-- </option>
									<?php
									$select = "";
									foreach($khoa as $value){
										$select .= '<option value = \''.$value['makhoa'].'\' >'.$value['tenkhoa'].' </option>';
									}
									echo $select;
									?>
								</select>
							</th>
							<th>
								<select name = "lop">
									<option value = "" > --Lớp-- </option>
									<?php
									$select = "";
									foreach($classes as $classname){
										$select .= '<option value = \''.$classname['malop'].'\' >'.$classname['tenlop'].' </option>';
									}
									echo $select;
									?>
								</select>
							</th>
							<th>
								<input type = "submit" name = "show" value = "Hiển thị"/>
							</th>
						</tr>
					</table>
				</form>
			</div>
			<div class="table-sm">
				<?php
				$classes = getAllClass();
				if(isset($_POST['show'])){
					$namhoc = $_POST['namhoc'];
					$quy = $_POST['quy'];
					$khoa = $_POST['khoa'];
					$lop = $_POST['lop'];
					if($namhoc == ""){
						if($quy == ""){
							if($khoa == ""){
								if($lop == ""){
									$classes = getAllClass();
								}else{
					//lọc theo lớp
									$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
									join giaovien on giaovien.magv = lophoc.magv 
									where lichhoc.malop = :malop ";
									$statement = $dbh->prepare($sql);
									$statement->bindValue(':malop', $lop);
									$statement->execute();
									$classes = $statement->fetchAll();
									$statement->closeCursor();
								}
			}else { //khóa có giá trị
				if($lop == ""){
					//lọc theo khóa
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where makhoa = :makhoa";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':makhoa', $khoa);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và khóa
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop  
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and makhoa = :makhoa";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':makhoa', $khoa);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}
		}else {//quý có giá trị
			if($khoa == ""){
				if($lop == ""){
					//lọc theo  quý
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where quy = :quy";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':quy', $quy);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và quý
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and quy = :quy";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':quy', $quy);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}else { //khoa có giá trị
				if($lop == ""){
					//lọc theo khóa và quý
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop  
					join giaovien on giaovien.magv = lophoc.magv
					where makhoa = :makhoa and quy = :quy";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':quy', $quy);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và khóa và quý
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and makhoa = :makhoa and quy = :quy";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':quy', $quy);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}
		}
	}else {//năm có giá trị
		if($quy == ""){
			if($khoa == ""){
				if($lop == ""){
					//lọc theo năm
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và năm học
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}else { //khóa có giá trị
				if($lop == ""){
					//lọc theo khóa va nam hoc
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where makhoa = :makhoa and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và khóa và năm học
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and makhoa = :makhoa and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}
		}else {//quý có giá trị
			if($khoa == ""){
				if($lop == ""){
					//lọc theo  quý và năm học
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where quy = :quy and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':quy', $quy);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và quý và năm học
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and quy = :quy and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':quy', $quy);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}else { //khoa có giá trị
				if($lop == ""){
					//lọc theo khóa và quý và năm học
					$sql = "select * from lichhoc join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where makhoa = :makhoa and quy = :quy and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':quy', $quy);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}else{
					//lọc theo lớp và khóa và quý va năm học
					$sql = "select * from lichhoc  join lophoc on lichhoc.malop = lophoc.malop 
					join giaovien on giaovien.magv = lophoc.magv
					where lichhoc.malop = :malop and makhoa = :makhoa and quy = :quy and namhoc = :namhoc";
					$statement = $dbh->prepare($sql);
					$statement->bindValue(':malop', $lop);
					$statement->bindValue(':makhoa', $khoa);
					$statement->bindValue(':quy', $quy);
					$statement->bindValue(':namhoc', $namhoc);
					$statement->execute();
					$classes = $statement->fetchAll();
					$statement->closeCursor();
				}
			}
		}
	}
}
try {
	
	$page = "<h1 class = 'display-4' style='text-align: center;'> Danh sách lớp học </h1>";
	$page .= '<table class = "table-striped" border=0 width=100%>';
	$page .='<th>STT</th><th>Mã lớp</th><th>Tên lớp</th><th>Giáo viên</th><th>Sĩ số</th><th>Đã đăng ký</th>';
	$page .='<th>Khai giảng</th><th>Năm học</th><th>Mã khóa</th><th>Quý</th><th>Buổi</th><th>Thứ</th><th>Bế giảng</th><th>Ghi chú</th>';
	$page .= '<th>Xóa</th><th>Cập nhật</th>';
	$stt = 1;
	foreach ($classes as $class) {
		$sum = countSt($class['malop']);
		$page .= '<tr style="color: #0d0d0d;">';
		$page .= '<td>' . $stt . '</td>';
		$page .= '<td>' . $class['malop'] . '</td>';
		$page .= '<td>' . $class['tenlop'] . '</td>';
		$page .= '<td>' . $class['tengv'] . '</td>';
		$page .= '<td>' . $class['siso'] . '</td>';
		$page .= '<td>' . $sum['dangky'] . '</td>';
		$page .= '<td>' . $class['khaigiang'] . '</td>';
		$page .= '<td>' . $class['namhoc'] . '</td>';
		$page .= '<td>' . $class['makhoa'] . '</td>';
		$page .= '<td>' . $class['quy'] . '</td>';
		$page .= '<td>' . $class['buoi'] . '</td>';
		$page .= '<td>' . $class['thu'] . '</td>';
		$page .= '<td>' . $class['begiang'] . '</td>';
		if($class['ghichu'] == "Đang mở"){
			$page .= '<td style = "color: blue;">' . $class['ghichu'] . '</td>';
		}else if($class['ghichu'] == "Đã đóng"){
			$page .= '<td style = "color: red;">' . $class['ghichu'] . '</td>';
		}else{
			$page .= '<td>' . $class['ghichu'] . '</td>';
		}
		
		$page .= "<td><a href=\"deleteClass.php?malop=".$class['malop']."\"
		onclick=\"return confirm('Are you sure to delete?')\" class='btn btn-primary btn-sm'>Xóa
		</a></td>";

		$page .= "<td><a href=\"updateClass.php?malop=".$class['malop']."\" class='btn btn-primary btn-sm'>Cập nhật</a></td>";
		$page .= '</tr>';
		$stt ++;
	}
	$page .= '</table>';
	echo $page;
} catch (PDOException $e) {
	print_r($e->getMessage());
}
?>
</div>
</div>
</div>
<!-- End of Main Content -->

<!-- Footer -->
<footer class="sticky-footer bg-white">
	<div class="container my-auto">
		<div class="copyright text-center my-auto">
			<span>Copyright &copy; Your Website 2019</span>
		</div>
	</div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
				<button class="close" type="button" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">×</span>
				</button>
			</div>
			<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
			<div class="modal-footer">
				<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
				<a class="btn btn-primary" href="../logout.php">Logout</a>
			</div>
		</div>
	</div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="../../vendor/jquery/jquery.min.js"></script>
<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="../../js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="../../vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="../../js/demo/chart-area-demo.js"></script>
<script src="../../js/demo/chart-pie-demo.js"></script>

</body>

</html>
<?php ob_end_flush();  $dbh=null;?>