<?php
require 'functionsClass.php';
delete($_GET['malop']);
header("location:listClass.php");
?>
