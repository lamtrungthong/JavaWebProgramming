<?php
include '../connectdb.php';
function getAllClass() { //theo năm học
	global $dbh;
	$query = 'SELECT lophoc.*,khaigiang,quy, buoi, thu, begiang,namhoc, tengv 
	FROM lophoc join lichhoc on lophoc.malop = lichhoc.malop join giaovien on giaovien.magv = lophoc.magv ';
	$statement = $dbh->prepare($query);
 $ch = $statement->execute(); //ch = true or false
 if (!$ch) {
 	print_r($statement->errorInfo());
 	exit();
 }
 $classes = $statement->fetchAll(); //lấy ra tất cả lop 
 $statement->closeCursor();
 return $classes;
}

function getClass($malop) {
	global $dbh;
	$query = 'SELECT lophoc.*,khaigiang,quy, buoi, thu, begiang,namhoc 
	FROM lichhoc join lophoc on lichhoc.malop = lophoc.malop
	WHERE lophoc.malop = :malop ' ;
	$statement = $dbh->prepare($query);
	$statement->bindValue(':malop', $malop);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 class
 $statement->closeCursor();
 return $result;
}
//đếm lượng hs trong từng lớp
function countSt($malop) {
	global $dbh;
	$query = 'SELECT count(malop) as dangky
	FROM hocsinh
	WHERE malop = :malop ' ;
	$statement = $dbh->prepare($query);
	$statement->bindValue(':malop', $malop);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 class
 $statement->closeCursor();
 return $result;
}

function addlophoc($malop,$tenlop,$magv,$siso,$makhoa,$ghichu) {
	global $dbh;
	$query2 = 'INSERT INTO lophoc(malop,tenlop, magv, makhoa,siso,ghichu)
	VALUES (:malop,:tenlop,:magv,:makhoa,:siso,:ghichu)';

	$statement2 = $dbh->prepare($query2);
	$statement2->bindValue(':malop', $malop);
	$statement2->bindValue(':tenlop', $tenlop);
	$statement2->bindValue(':makhoa', $makhoa);
	$statement2->bindValue(':magv', $magv);
	$statement2->bindValue(':siso', $siso);
	$statement2->bindValue(':ghichu', $ghichu);
	$statement2->execute();
	$statement2->closeCursor();

}

function addlichhoc($malop,$khaigiang,$quy, $buoi, $thu, $begiang,$namhoc) {
	global $dbh;
	$query = 'INSERT INTO lichhoc(malop,khaigiang,quy, buoi, thu, begiang,namhoc)
	VALUES (:malop,:khaigiang,:quy, :buoi, :thu, :begiang,:namhoc)';
	
	$statement = $dbh->prepare($query);
	$statement->bindValue(':malop', $malop);
	$statement->bindValue(':khaigiang', $khaigiang);
	$statement->bindValue(':namhoc', $namhoc);
	$statement->bindValue(':quy', $quy);
	$statement->bindValue(':buoi', $buoi);
	$statement->bindValue(':thu', $thu);
	$statement->bindValue(':begiang', $begiang);
	
	$statement->execute();
	$statement->closeCursor();

}
function updatelophoc($malop,$tenlop,$magvupdate,$makhoa,$siso,$ghichu, $magv) {
	global $dbh;
	$sql = "UPDATE lophoc
	SET malop = :malop,
	tenlop = :tenlop,
	magv = :magvupdate,
	makhoa = :makhoa,
	siso = :siso,
	ghichu = :ghichu
	WHERE malop = :malop and magv = :magv";
	
	
	$statement2 = $dbh->prepare($sql);
	$statement2->bindValue(':malop', $malop);
	$statement2->bindValue(':tenlop', $tenlop);
	$statement2->bindValue(':magv', $magv);
	$statement2->bindValue(':makhoa', $makhoa);
	$statement2->bindValue(':magvupdate', $magvupdate);
	$statement2->bindValue(':siso', $siso);
	$statement2->bindValue(':ghichu', $ghichu);

 $updateclass = $statement2->execute(); //trả về true hoặc false
 if (!$updateclass)
 	print_r($statement2->errorInfo());

 $statement2->closeCursor();
 
 return $updateclass;

}

function updatelichhoc($malop,$khaigiang,$namhoc,$quy, $buoi, $thu, $begiang) {
	global $dbh;
	
	
	$sql = "UPDATE lichhoc
	SET malop = :malop,
	khaigiang = :khaigiang,
	quy = :quy,
	buoi = :buoi,
	thu = :thu,
	begiang = :begiang,
	namhoc = :namhoc
	WHERE malop = :malop";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':malop', $malop);
	$statement->bindValue(':khaigiang', $khaigiang);
	$statement->bindValue(':namhoc', $namhoc);
	$statement->bindValue(':quy', $quy);
	$statement->bindValue(':buoi', $buoi);
	$statement->bindValue(':thu', $thu);
	$statement->bindValue(':begiang', $begiang);
	
 $updateclass = $statement->execute();; //trả về true hoặc false
 if (!$updateclass)
 	print_r($statement->errorInfo());
 $statement->closeCursor();
 
 return $updateclass;
}
function delete($malop) {
	global $dbh;
	$query = 'DELETE FROM lichhoc WHERE malop = :malop';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':malop', $malop);
 $class_del = $statement->execute(); //trả về true hoặc false
 $statement->closeCursor();
 $query2 = 'DELETE FROM lophoc WHERE malop = :malop';
 $statement2 = $dbh->prepare($query2);
 $statement2->bindValue(':malop', $malop);
 $class_del = $statement2->execute(); //trả về true hoặc false
 $statement2->closeCursor();

}

?>
