<?php 
echo $_GET['pay'];
?>