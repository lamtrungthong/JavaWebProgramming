<!DOCSTYPE html>
<?php 
ob_start();
session_start();
require '../../islogin.php';
require 'functionsSt.php';
?>
<?php 
	//lấy ra các khóa có trong trung tâm
$khoa = "select * from khoa";
$statement = $dbh->prepare($khoa);
$statement->execute();
$result = $statement->fetchAll();
$statement->closeCursor();
?>

<?php 
	//lấy ra các lớp có trong trung tâm
$khoa = "select * from lophoc";
$statement = $dbh->prepare($khoa);
$statement->execute();
$class = $statement->fetchAll();
$statement->closeCursor();
?>
<html>
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Danh sách học sinh</title>

	<!-- Custom fonts for this template-->
	<link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

	<!-- Custom styles for this template-->
	<link href="../../css/sb-admin-2.min.css" rel="stylesheet">
	<style type="text/css">
		@import url('https://fonts.googleapis.com/css?family=Raleway');
		html, body {
			width: 100%;
			height: 100%;
			font-family: 'Raleway';
			font-size: 16px;	
			font-weight: bold;
		}
	</style>

</head>

<body id="page-top">

	<!-- Page Wrapper -->
	<div id="wrapper">

		<!-- Sidebar -->
		<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

			<!-- Sidebar - Brand -->
			<a class="sidebar-brand d-flex align-items-center justify-content-center" href="../admin.php">
				<div class="sidebar-brand-icon rotate-n-15">
					<i class="fas fa-laugh-wink"></i>
				</div>
				<div class="sidebar-brand-text mx-3">Hi Admin!</div>
			</a>

			<!-- Divider -->
			<hr class="sidebar-divider my-0">

			<!-- Nav Item - Dashboard -->
			<li class="nav-item active">
				<a class="nav-link" href="">
					<i class="fas fa-fw fa-tachometer-alt"></i>
					<span>Menu</span></a>
				</li>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
      <!-- <div class="sidebar-heading">
        Interface
    </div> -->

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
    		<i class="fas"></i>
    		<span>Giáo Viên</span>
    	</a>
    	<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="../QLGV/listTeacher.php">Thông tin Giáo Viên</a>
    			<a class="collapse-item" href="../QLGV/manageSal.php">Lương Giáo Viên</a>
    		</div>
    	</div>
    </li>

    <!-- Nav Item - Utilities Collapse Menu -->
    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
    		<i class="fas"></i>
    		<span>Học Viên</span>
    	</a>
    	<div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="listStudent.php">Thông tin học viên</a>
    			<a class="collapse-item" href="../QLPH/listParent.php">Thông tin phụ huynh</a>
    			<a class="collapse-item" href="../manageFee.php">Thông tin học phi</a>
    		</div>
    	</div>
    </li>

    <li class="nav-item">
    	<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapselops" aria-expanded="true" aria-controls="collapsePages">
    		<i class="fas"></i>
    		<span>Lớp Học</span>
    	</a>
    	<div id="collapselops" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
    		<div class="bg-white py-2 collapse-inner rounded">
    			<a class="collapse-item" href="../QLLop/listClass.php">Thông tin lớp học</a>
    		</div>
    	</div>
    </li>
    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
    	<button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

	<!-- Main Content -->
	<div id="content">

		<!-- Topbar -->
		<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

			<!-- Sidebar Toggle (Topbar) -->
			<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
				<i class="fa fa-bars"></i>
			</button>

			<!-- Topbar Search -->
			<form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search" action="" method="post">
				<div class="input-group">
					<input type="text" class="form-control bg-light border-0 small" name="hocsinh" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
					<div class="input-group-append">
						<button class="btn btn-primary"  type="submit" name="Search">
							<i class="fas fa-search fa-sm"></i>
						</button>
					</div>
				</div>
			</form>

			<!-- Topbar Navbar -->
			<ul class="navbar-nav ml-auto">

				<!-- Nav Item - Search Dropdown (Visible Only XS) -->
				<li class="nav-item dropdown no-arrow d-sm-none">
					<a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<i class="fas fa-search fa-fw"></i>
					</a>
					<!-- Dropdown - Messages -->
					<div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
						<form class="form-inline mr-auto w-100 navbar-search">
							<div class="input-group">
								<input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
								<div class="input-group-append">
									<button class="btn btn-primary" type="button">
										<i class="fas fa-search fa-sm"></i>
									</button>
								</div>
							</div>
						</form>
					</div>
				</li>


				<div class="topbar-divider d-none d-sm-block"></div>

				<!-- Nav Item - User Information -->
				<li class="nav-item dropdown no-arrow">
					<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
						<span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
						<img class="img-profile rounded-circle" src="../../img/profile.png">
					</a>
					<!-- Dropdown - User Information -->
					<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
						<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
							<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
							Logout
						</a>
					</div>
				</li>

			</ul>

		</nav>
		
		<div class="container-fluid">
			<form  action = "" method = "post">
				<div class="table-sm">
					<a class='btn btn-primary btn-sm' href='checkAddSt.php'>Thêm học sinh</a>
					<table class="table-striped" >
						<th><label>Lọc</label></th><th><select name = "khoa">
							<option value = "" > --Khóa--</option>
							<?php

							foreach($result as $value){
								$select .= '<option value = \''.$value['makhoa'].'\'>'.$value['tenkhoa'].'</option>';
							}
							$select .='</select></th><th><select name = lop>';
							$select .= '<option value = "" > --Lớp--</option>';
							foreach($class as $value){
								$select .= '<option value = \''.$value['malop'].'\'>'.$value['tenlop'].'</option>';
							}
							$select .='</select></th> ';
							$select .='<th><input type = submit value = Lọc name = loc /></th></tr> ';
							$select .='</table>';
							echo $select;
							?>
						</div>
					</form>

					<?php
					if(islogin() == true){
						$students = getAllStudent();
						if (isset($_POST['Search'])){
							$hocsinh = $_POST['hocsinh'];

							$tenhs = "%$hocsinh%";
							$sql = 'SELECT distinct *
									FROM hocsinh join lophoc on hocsinh.malop = lophoc.malop
									where tenhs like :hocsinh';
									$statement = $dbh->prepare($sql);
									$statement->bindValue(':hocsinh', $tenhs);
									$statement->execute();
									$students = $statement->fetchAll(); 
									$statement->closeCursor();
						}
						if (isset($_POST['loc'])){
							$makhoa = $_POST['khoa'];
							$malop = $_POST['lop'];
							if($makhoa == ""){
								if($malop == ""){
									$students = getAllStudent();
								}
								else {
									$sql = 'SELECT distinct *
									FROM hocsinh join lophoc on hocsinh.malop = lophoc.malop
									where lophoc.malop = :malop';
									$statement = $dbh->prepare($sql);
									$statement->bindValue(':malop', $malop);
									$statement->execute();
									$students = $statement->fetchAll(); 
									$statement->closeCursor();
								}
							}else{
								if($malop == ""){
									$sql = 'SELECT distinct *
									FROM hocsinh join lophoc on hocsinh.malop = lophoc.malop
									where lophoc.makhoa = :makhoa ';
									$statement = $dbh->prepare($sql);
									$statement->bindValue(':makhoa', $makhoa);
									$statement->execute();
									$students = $statement->fetchAll(); 
									$statement->closeCursor();
								}
							}
						}
							//kiểm tra thông tin phụ huynh đã tồn tại hay chưa
						function Parent($hs)
						{
							global $dbh;
							$sql = 'SELECT distinct maph
							FROM phuhuynh
							where mahs = :mahs';
							$statement = $dbh->prepare($sql);
							$statement->bindValue(':mahs', $hs);
							$statement->execute();
							$parent = $statement->fetch(); 
							$statement->closeCursor();
							return $parent;
						}
						function Fee($hs, $lop)
						{
							global $dbh;
							$sql = 'SELECT distinct *
							FROM hocphi_hocsinh join hocphi on hocphi_hocsinh.makhoa = hocphi.makhoa
							where mahs = :mahs and malop = :malop';
							$statement = $dbh->prepare($sql);
							$statement->bindValue(':mahs', $hs);
							$statement->bindValue(':malop', $lop);
							$statement->execute();
							$student = $statement->fetch(); 
							$statement->closeCursor();
							return $student;
						}
						try {
							$stt = 1;
							$page = "<h1 style= 'text-align: center;'> Danh sách học sinh </h1>";
							$page .= '<table class = "table-striped" width= 100%>';
							$page .='<th scope=col>STT</th><th scope=col >Mã HS</th><th scope=col>Tên HS</th><th scope=col>Tên lớp</th><th scope=col>Tuổi</th><th scope=col>Giới tính</th>';
							$page .='<th scope=col>SDT</th><th scope=col>Email</th><th scope=col>Địa chỉ</th>';
							$page .= '<th scope=col>Xóa</th><th scope=col>Cập nhật</th><th scope=col>TT phụ huynh</th><th scope=col>Học phí</th>';
							foreach ($students as $stu) {
								$page .= '<tr style="color: #0d0d0d;" >';
								$page .= '<td>' .$stt. '</td>';
								$page .= '<td>' . $stu['mahs'] . '</td>';
								$page .= '<td>' . $stu['tenhs'] . '</td>';
								$page .= '<td>' . $stu['tenlop'] . '</td>';
								$page .= '<td>' . $stu['tuoi'] . '</td>';
								$page .= '<td>' . $stu['gioitinh'] . '</td>';
								$page .= '<td>' . $stu['sdt'] . '</td>';
								$page .= '<td>' . $stu['email'] . '</td>';
								$page .= '<td>' . $stu['diachi'] . '</td>';
								$page .= "<td><a href=\"deleteSt.php?mahs=".$stu['mahs']."\"
								onclick=\"return confirm('Are you sure delete?')\" class='btn btn-primary btn-sm'>Xóa
								</a></td>";
								$page .= "<td><a href=\"updateSt.php?mahs=".$stu['mahs']."\" class='btn btn-primary btn-sm'>Cập nhật</a></td>";

								$Parent = Parent($stu['mahs']);
								if($Parent['maph'] == ""){
									$page .= "<td><a href=\"../QLPH/InfoParent.php?mahs=".$stu['mahs']."\" class='btn btn-primary btn-sm'>Thông tin</a></td>";
								}else {
									$page .= "<td><a href=\"../QLPH/InfoParent.php?mahs=".$stu['mahs']."\" class='btn btn-danger btn-sm'>Thông tin</a></td>";
								}

								$st = Fee($stu['mahs'], $stu['malop']);
								$hocphi = $st['hocphi'] - $st['hocphi']*$st['giamgia']/100;
								if($st['dadong'] == $hocphi){
									$page .= "<td><a href=\"fees.php?mahs=".$stu['mahs']."&malop=".$stu['malop']."\" class='btn btn-danger btn-sm'>Đóng học</a></td>";
								}else if($st['dadong'] > 0 && $st['dadong'] < $hocphi){
									$page .= "<td><a href=\"fees.php?mahs=".$stu['mahs']."&malop=".$stu['malop']."\" class='btn btn-warning btn-sm'>Đóng học</a></td>";
								}else if($st['dadong'] == 0) {
									$page .= "<td><a href=\"fees.php?mahs=".$stu['mahs']."&malop=".$stu['malop']."\" class='btn btn-primary btn-sm'>Đóng học</a></td>";
								}

								$page .= '</tr>';
								$stt ++;
							}

							$page .= '</table>';
							echo $page;
						} catch (PDOException $e) {
							print_r($e->getMessage());
						}
					}else {
						echo "<h3>Bạn chưa đăng nhập</h3>";
						echo "<a href=../../login.php>Click vào đây để đăng nhập</a>";
					}
					?>

				</div>
			</div>
			<!-- End of Main Content -->

			<!-- Footer -->
			<footer class="sticky-footer bg-white">
				<div class="container my-auto">
					<div class="copyright text-center my-auto">
						<span>Copyright &copy; Your Website 2019</span>
					</div>
				</div>
			</footer>
			<!-- End of Footer -->

		</div>
		<!-- End of Content Wrapper -->

	</div>
	<!-- End of Page Wrapper -->

	<!-- Scroll to Top Button-->
	<a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	</a>

	<!-- Logout Modal-->
	<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
					<a class="btn btn-primary" href="../logout.php">Logout</a>
				</div>
			</div>
		</div>
	</div>

	<!-- Bootstrap core JavaScript-->
	<script src="../../vendor/jquery/jquery.min.js"></script>
	<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

	<!-- Core plugin JavaScript-->
	<script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

	<!-- Custom scripts for all pages-->
	<script src="../../js/sb-admin-2.min.js"></script>

	<!-- Page level plugins -->
	<script src="../../vendor/chart.js/Chart.min.js"></script>

	<!-- Page level custom scripts -->
	<script src="../../js/demo/chart-area-demo.js"></script>
	<script src="../../js/demo/chart-pie-demo.js"></script>

</body>

</html>
<?php ob_end_flush();  $dbh=null;?>
