

<?php
include '../connectdb.php';
function adduser ($mahs, $username, $password){
	global $dbh;
	$adduser = 'INSERT INTO userhs (mahs, username, password) VALUES (:mahs,:username ,:password)';
	$statement = $dbh->prepare($adduser);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);

	$statement->execute();
	$statement->closeCursor();
}
?>