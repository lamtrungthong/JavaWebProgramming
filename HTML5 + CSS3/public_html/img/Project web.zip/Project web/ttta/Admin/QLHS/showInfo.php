<!DOCSTYPE html>
<!DOCTYPE html>
<html>
	<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">

	<title>Danh sách học sinh</title>

	<!-- Custom fonts for this template-->
	<link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

	<!-- Custom styles for this template-->
	<link href="../../css/sb-admin-2.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>

<body>


<?php 
session_start();
require '../../islogin.php';
require 'functionsSt.php';
?>
<?php 
$sdt = $_GET['sdt'];

$sql = "select * from hocsinh where sdt = :sdt";
$statement = $dbh->prepare($sql);
$statement->bindValue(':sdt', $sdt);
$statement->execute();
$st = $statement->fetch(); 
$statement->closeCursor();
if($st['mahs'] != ""){
	echo "<table class = 'table-striped' width = 100% style = 'color: white;background-color: blue;'>";
	echo "<tr><th>Mã HS</th><th>Mã lớp</th><th>Tên HS</th><th>Tuổi</th><th>Giới tính</th>";
	echo "<th>SĐT</th><th>Email</th><th>Địa chỉ</th><th></th></tr>";

	echo "<tr><td>".$st['mahs']."</td><td>".$st['malop']."</td><td>".$st['tenhs']."</td><td>".$st['tuoi']."</td><td>".$st['gioitinh']."</td>";
	echo "<td>".$st['sdt']."</td><td>".$st['email']."</td><td>".$st['diachi']."</td>";
	
	echo "<td><a class='btn btn-primary btn-lg' href=\"updateClassSt.php?mahs=".$st['mahs']."\">Thêm lớp</a></td>";
	echo "</tr><table>";
}else {
	echo "<a class='btn btn-primary btn-lg' href='addStudent.php?sdt=".$sdt."'>Thêm mới</a>";
}
?>

</body>
</html>
<?php ob_end_flush();  $dbh=null;?>