<?php
require 'functionsSt.php';
delete($_GET['mahs']);
header("location:listStudent.php");
?>