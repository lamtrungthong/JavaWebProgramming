<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php 
$discount = $_GET['discount'];
	echo $discount;
 ?>
</body>
</html>