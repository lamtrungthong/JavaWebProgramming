<?php
include '../connectdb.php';
function getAllStudent() {
	global $dbh;
	$sql = 'SELECT distinct *
	FROM hocsinh join lophoc on hocsinh.malop = lophoc.malop';
	$students = $dbh->query($sql);
	return $students;
}
function getStudent($mahs) {
	global $dbh;
	$query = 'SELECT distinct hocsinh.*, lophoc.tenlop
	FROM hocsinh join lophoc on hocsinh.malop = lophoc.malop
	WHERE mahs = :mahs';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':mahs', $mahs);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 student
 $statement->closeCursor();
 return $result;
}

function add($mahs,$malop,$tenhs, $tuoi,$gioitinh, $sdt,$email, $diachi) {
	global $dbh;
	$query = 'INSERT INTO hocsinh(mahs,malop,tenhs, tuoi,gioitinh, sdt,email, diachi)
	VALUES (:mahs,:malop,:tenhs, :tuoi,:gioitinh, :sdt,:email, :diachi)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':malop', $malop);
	$statement->bindValue(':tenhs', $tenhs);
	$statement->bindValue(':tuoi', $tuoi);
	$statement->bindValue(':gioitinh', $gioitinh);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);
	$statement->execute();
	$statement->closeCursor();
	
}

function addfees($makhoa,$malop,$mahs ) {
	global $dbh;
	$query = 'INSERT INTO hocphi_hocsinh(makhoa,malop,mahs,dadong,giamgia)
	VALUES (:makhoa,:malop,:mahs, :dadong, :giamgia)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':makhoa', $makhoa);
	$statement->bindValue(':malop', $malop);
	$statement->bindValue(':dadong', 0);
	$statement->bindValue(':giamgia', 0);
	$statement->execute();
	$statement->closeCursor();
	
}
function adddiemdanh($mahs,$malop) {
	global $dbh;
	$query = 'INSERT INTO diemdanh(mahs,malop,dahoc,danghi)
	VALUES (:mahs,:malop, :dahoc, :danghi)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':malop', $malop);
	$statement->bindValue(':dahoc', 0);
	$statement->bindValue(':danghi', 0);
	$statement->execute();
	$statement->closeCursor();
	
}
function update($mahs,$malop,$tenhs, $tuoi,$gioitinh, $sdt,$email, $diachi) {
	global $dbh;
	$sql = "UPDATE hocsinh
	SET 
	tenhs = :tenhs,
	tuoi = :tuoi,
	gioitinh = :gioitinh,
	sdt = :sdt,
	email = :email,
	diachi = :diachi
	WHERE mahs = :mahs";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':tenhs', $tenhs);
	$statement->bindValue(':tuoi', $tuoi);
	$statement->bindValue(':gioitinh', $gioitinh);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);

 $updateSt = $statement->execute(); //trả về true hoặc false
 if (!$updateSt)
 	print_r($statement->errorInfo());
 $statement->closeCursor();
 return $updateSt;

}
function delete($mahs) {
	global $dbh;
	$query = 'DELETE FROM hocsinh WHERE mahs = :mahs';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':mahs', $mahs);
 $st_del = $statement->execute(); //trả về true hoặc false
 $statement->closeCursor();
 return $st_del;
}
?>
