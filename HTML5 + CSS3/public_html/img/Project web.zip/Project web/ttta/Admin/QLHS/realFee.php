<!DOCTYPE html>
<?php 
session_start(); 
include '../connectdb.php';
?>
<html>
<head>

</head>
<body>

	<?php
	$discount = $_GET['realfee'];

	$sql = "select * from hocphi_hocsinh join hocphi on hocphi_hocsinh.makhoa = hocphi.makhoa where mahs = :mahs";
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':mahs', $_SESSION["mahs"]);
	$statement->execute();
	$fees = $statement->fetch(); 
	$statement->closeCursor();
	
	$realfee = 0;
	
	$realfee = $fees['hocphi'] - $fees['hocphi']*$discount/100;
	echo $realfee;
	
	?>
</body>
</html>