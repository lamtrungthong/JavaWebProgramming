<?php
require 'functionsTeach.php';
delete($_GET['magv']);
header("location:listTeacher.php");
?>
