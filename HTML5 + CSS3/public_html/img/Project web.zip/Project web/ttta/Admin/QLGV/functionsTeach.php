<?php
include '../connectdb.php';
function getAllTeacher() {
	global $dbh;
	$sql = 'SELECT giaovien.*, ((luongcb+trocap+thuong)/26)*ngaycong as salary FROM giaovien join luonggv on giaovien.magv = luonggv.magv' ;
	$teachers = $dbh->query($sql);
	return $teachers;
}
function getTeacher($magv) {
	global $dbh;
	$query = 'SELECT *
	FROM giaovien
	WHERE magv = :magv';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':magv', $magv);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 teach
 $statement->closeCursor();
 return $result;
}
function add($magv,$tengv, $tuoi,$gioitinh, $sdt,$email, $diachi, $anh) {
	global $dbh;
	$query = 'INSERT INTO giaovien(magv,tengv, tuoi,gioitinh, sdt,email, diachi, anh)
	VALUES (:magv,:tengv, :tuoi,:gioitinh, :sdt,:email, :diachi, :anh)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':magv', $magv);
	$statement->bindValue(':tengv', $tengv);
	$statement->bindValue(':tuoi', $tuoi);
	$statement->bindValue(':gioitinh', $gioitinh);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);
	$statement->bindValue(':anh', $anh);
	$statement->execute();
	$statement->closeCursor();

}
function addSal($magv,$luongcb, $ngaycong,$trocap, $thuong, $traluong) {
	global $dbh;
	$query = 'INSERT INTO luonggv(magv,luongcb, ngaycong,trocap, thuong, traluong)
	VALUES (:magv,:luongcb, :ngaycong,:trocap, :thuong, :traluong)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':magv', $magv);
	$statement->bindValue(':luongcb', $luongcb);
	$statement->bindValue(':ngaycong', $ngaycong);
	$statement->bindValue(':trocap', $trocap);
	$statement->bindValue(':thuong', $thuong);
	$statement->bindValue(':traluong', $traluong);
	$statement->execute();
	$statement->closeCursor();

}
function updateSal($magv,$luongcb, $ngaycong,$trocap, $thuong, $traluong) {
	global $dbh;
	$sql = "UPDATE luonggv
	SET magv = :magv,
	luongcb = :luongcb,
	ngaycong = :ngaycong,
	trocap = :trocap,
	thuong = :thuong,
	traluong= :traluong
	WHERE magv = :magv";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':magv', $magv);
	$statement->bindValue(':luongcb', $luongcb);
	$statement->bindValue(':ngaycong', $ngaycong);
	$statement->bindValue(':trocap', $trocap);
	$statement->bindValue(':thuong', $thuong);
	$statement->bindValue(':traluong', $traluong);

 $updateSal = $statement->execute(); //trả về true hoặc false
 if (!$updateSal)
 	print_r($statement->errorInfo());
 $statement->closeCursor();
}

function Salary($magv) {
	global $dbh;
	$sql = "select luongcb from luonggv where magv = :magv";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':magv', $magv);
	$salary = $statement->execute(); 
	$statement->closeCursor();
	//Lương tháng = [(Lương + Các khoản phụ cấp)]/ 26]* Số ngày làm việc thực tế.
	
	return $salary['luongcb'];
}
function update($magv,$tengv, $tuoi,$gioitinh, $sdt,$email, $diachi, $anh) {
	global $dbh;
	$sql = "UPDATE giaovien
	SET magv = :magv,
	tengv = :tengv,
	tuoi = :tuoi,
	gioitinh = :gioitinh,
	sdt = :sdt,
	email = :email,
	diachi = :diachi,
	anh = :anh
	WHERE magv = :magv";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':magv', $magv);
	$statement->bindValue(':tengv', $tengv);
	$statement->bindValue(':tuoi', $tuoi);
	$statement->bindValue(':gioitinh', $gioitinh);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);
	$statement->bindValue(':anh', $anh);

 $updateTeach = $statement->execute(); //trả về true hoặc false
 if (!$updateTeach)
 	print_r($statement->errorInfo());

 $statement->closeCursor();
 return $updateTeach;

}
function delete($magv) {
	global $dbh;
	$query = 'DELETE FROM giaovien WHERE magv = :magv';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':magv', $magv);
 $teach_del = $statement->execute(); //trả về true hoặc false
 $statement->closeCursor();
 return $teach_del;
}

?>
