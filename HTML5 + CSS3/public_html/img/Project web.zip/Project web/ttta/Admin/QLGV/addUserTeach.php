
<?php
include '../connectdb.php';
function adduser ($magv, $username, $password){
	global $dbh;
	$adduser = 'INSERT INTO usergv (magv, username, password) VALUES (:magv,:username ,:password)';
	$statement = $dbh->prepare($adduser);
	$statement->bindValue(':magv', $magv);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);

	$statement->execute();
	$statement->closeCursor();
}
?>