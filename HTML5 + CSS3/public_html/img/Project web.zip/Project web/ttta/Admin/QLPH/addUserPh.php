<?php
include '../connectdb.php';
function adduser ($maph, $username, $password){
	global $dbh;
	$adduser = 'INSERT INTO userph (maph, username, password) VALUES (:maph,:username ,:password)';
	$statement = $dbh->prepare($adduser);
	$statement->bindValue(':maph', $maph);
	$statement->bindValue(':username', $username);
	$statement->bindValue(':password', $password);

	$statement->execute();
	$statement->closeCursor();
}
?>