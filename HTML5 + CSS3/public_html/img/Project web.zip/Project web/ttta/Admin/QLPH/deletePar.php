<?php
require 'functionsParent.php';
delete($_GET['maph']);
header("location:listParent.php");
?>