<?php
include '../connectdb.php';
function getAllParent() {
	global $dbh;
	$sql = 'SELECT maph, tenph, hocsinh.tenhs, phuhuynh.sdt, phuhuynh.email, phuhuynh.diachi 
	FROM phuhuynh join hocsinh on phuhuynh.mahs = hocsinh.mahs';
	$parents = $dbh->query($sql);
	return $parents;
}
function getParent($maph, $mahs) {
	global $dbh;
	$query = 'SELECT maph, tenph, hocsinh.tenhs, sdt, email, diachi 
	FROM phuhuynh join hocsinh on phuhuynh.mahs = hocsinh.mahs
	WHERE maph = :maph and mahs = :mahs';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':maph', $maph);
	$statement->execute();
 $result = $statement->fetch(); //lấy ra 1 student
 $statement->closeCursor();
 return $result;
}

function add($maph, $mahs, $tenph, $sdt,$email, $diachi) {
	global $dbh;
	$query = 'INSERT INTO phuhuynh(maph,mahs,tenph,sdt,email,diachi)
	VALUES (:maph,:mahs,:tenph,:sdt,:email,:diachi)';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':maph', $maph);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':tenph', $tenph);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);
	$statement->execute();
	$statement->closeCursor();
	
}

function update($maph,$mahs, $tenph, $sdt,$email, $diachi) {
	global $dbh;
	$sql = "UPDATE phuhuynh
	SET maph = :maph,
	mahs = :mahs,
	tenph = :tenph,
	sdt = :sdt,
	email = :email,
	diachi = :diachi
	WHERE mahs = :mahs";
	
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':maph', $maph);
	$statement->bindValue(':mahs', $mahs);
	$statement->bindValue(':tenph', $tenph);
	$statement->bindValue(':sdt', $sdt);
	$statement->bindValue(':email', $email);
	$statement->bindValue(':diachi', $diachi);

 $updatePar = $statement->execute(); //trả về true hoặc false
 if (!$updatePar)
 	print_r($statement->errorInfo());
 $statement->closeCursor();
 
}
function delete($maph) {
	global $dbh;
	$query = 'DELETE FROM phuhuynh WHERE maph = :maph';
	$statement = $dbh->prepare($query);
	$statement->bindValue(':maph', $maph);
 $par_del = $statement->execute(); //trả về true hoặc false
 $statement->closeCursor();

}
?>
