<!DOCSTYPE html>
<html>
<head>

	<meta http-equiv="Content-Type" content="text/html;
	charset=UTF-8">
	<style type="text/css">
		label{
			width: 70px;
			float:left;
		}
	</style>
</head>
<body>
	<a href = "../welcome.php"> Trang chủ </a> <br/>
	<a href = "manage.php"> Quản lý nhân sự </a> <br/>
	<form action = "" method = "post">
		<label> Ma khoa:</label> <input type ="text" name ="makhoa"/><br/><br/> 
		<label> Ten khoa:</label> <input type ="text" name ="tenkhoa"/><br/><br/>
		<input type = "submit" name = "sb" value = "add"/>
	</form>
	
	<?php 
	include 'connectdb.php';
	if(isset($_POST['sb'])){
		$makhoa = $_POST['makhoa'];
		$tenkhoa = $_POST['tenkhoa'];
		
		$sql = "insert into khoa (makhoa, tenkhoa) values (:makhoa, :tenkhoa)";
		
		$statement = $dbh->prepare($sql);
		$statement->bindValue(':makhoa', $makhoa);
		$statement->bindValue(':tenkhoa', $tenkhoa);
		$statement->execute();
		$statement->closeCursor();
	}
	?>
</body>
</html>