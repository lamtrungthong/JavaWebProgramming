<!DOCTYPE html>
<?php 
ob_start();
session_start();
include 'connectdb.php';
?>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin</title>

  <!-- Custom fonts for this template-->
  <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="../css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="admin.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Hi Admin!</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Menu</span></a>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Heading -->
      <!-- <div class="sidebar-heading">
        Interface
      </div> -->

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas"></i>
          <span>Giáo Viên</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="QLGV/listTeacher.php">Thông tin Giáo Viên</a>
            <a class="collapse-item" href="QLGV/manageSal.php">Lương Giáo Viên</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas"></i>
          <span>Học Viên</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="QLHS/listStudent.php">Thông tin học viên</a>
            <a class="collapse-item" href="QLPH/listParent.php">Thông tin phụ huynh</a>
            <a class="collapse-item" href="manageFee.php">Thông tin học phi</a>
          </div>
        </div>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapselops" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas"></i>
          <span>Lớp Học</span>
        </a>
        <div id="collapselops" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           <a class="collapse-item" href="QLLop/listClass.php">Thông tin lớp học</a>

         </div>
       </div>
     </li>
     <!-- Sidebar Toggler (Sidebar) -->
     <div class="text-center d-none d-md-inline">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

  </ul>
  <!-- End of Sidebar -->

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

      <!-- Topbar -->
      <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

        <!-- Sidebar Toggle (Topbar) -->
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
          <i class="fa fa-bars"></i>
        </button>

        <!-- Topbar Search -->
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
          <div class="input-group">
            <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
            <div class="input-group-append">
              <button class="btn btn-primary" type="button">
                <i class="fas fa-search fa-sm"></i>
              </button>
            </div>
          </div>
        </form>

        <!-- Topbar Navbar -->
        <ul class="navbar-nav ml-auto">

          <!-- Nav Item - Search Dropdown (Visible Only XS) -->
          <li class="nav-item dropdown no-arrow d-sm-none">
            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-search fa-fw"></i>
            </a>
            <!-- Dropdown - Messages -->
            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
              <form class="form-inline mr-auto w-100 navbar-search">
                <div class="input-group">
                  <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                  <div class="input-group-append">
                    <button class="btn btn-primary" type="button">
                      <i class="fas fa-search fa-sm"></i>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </li>


          <div class="topbar-divider d-none d-sm-block"></div>

          <!-- Nav Item - User Information -->
          <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <span class="mr-2 d-none d-lg-inline text-gray-600 small">Admin</span>
              <img class="img-profile rounded-circle" src="../img/profile.png">
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
              <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                Logout
              </a>
            </div>
          </li>

        </ul>

      </nav>
      <!-- End of Topbar -->

      <!-- Begin Page Content -->
      <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Overviews</h1>
          <a href="addAdvertise.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas far fa-smile fa-sm text-white-50"></i> Add poster</a>
        </div>

        <!-- Content Row -->
        <div class="row">

          <!-- Earnings (Monthly) Card Example -->
          <?php 
                  //Tổng học phí Chưa đóng, đã đóng
          $sql_f = "Select * from hocphi_hocsinh join hocphi on hocphi_hocsinh.makhoa = hocphi.makhoa";
          $statement = $dbh->prepare($sql_f);
          $statement->execute();
          $fees = $statement->fetchAll(); 
          $statement->closeCursor();
          $chuadong = 0;
          $dadong = 0;
          foreach ($fees as $key => $value) {
            $realfee = $value['hocphi'] - $value['hocphi']*$value['giamgia']/100;
            $phaidong = $realfee - $value['dadong'];

            $chuadong += $phaidong;
            $dadong += $value['dadong'];
          }
          ?>
          <div class="col-xl-4 col-md-8 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-4">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total tuition fees</div>
                    <div class="table-sm">
                      <table class="table-striped">

                        <thead>
                          <tr>
                            <th>
                              Tổng tiền chưa thu
                            </th>
                            <th>
                              Tổng tiền dã thu
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>
                              <?php echo number_format ($chuadong)." VND"; ?>
                            </td>
                            <td>
                              <?php echo number_format ($dadong)." VND"; ?>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                      <div> 
                        Tổng học phí: <?php echo number_format ($chuadong+$dadong). " VND"; ?>
                      </div>
                    </div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Earnings (Monthly) Card Example -->
          <?php 
          $sql_sal = "Select sum(((luongcb+trocap+thuong)/26)*ngaycong) as salary from luonggv";
          $statement = $dbh->prepare($sql_sal);
          $statement->execute();
          $salary = $statement->fetch(); 
          $statement->closeCursor();
          ?>
          <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total salary teacher</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format( round($salary['salary']))." VND"; ?></div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo "Tháng: ". date('m') . " Năm: ". date('Y'); ?> </div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Pending Requests Card Example -->
          <?php 
          $sql_st = "Select  count(distinct mahs) as sum_st from hocsinh join lophoc on hocsinh.malop = lophoc.malop
          where ghichu = :ghichu" ;
          $statement = $dbh->prepare($sql_st);
          $statement->bindValue(':ghichu', 'Đang mở');
          $statement->execute();
          $sum_st = $statement->fetch(); 
          $statement->closeCursor();

          ?>
          <div class="col-xl-4 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
              <div class="card-body">
                <div class="row no-gutters align-items-center">
                  <div class="col mr-2">
                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Total students</div>
                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $sum_st['sum_st']." Students"; ?></div>
                  </div>
                  <div class="col-auto">
                    <i class="fas fa-child fa-2x text-gray-300"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Content Row -->

        <div class="row">
          <!-- Area Chart -->
          <div class="col-xl-6 col-lg-5">
            <div class="card shadow mb-4">
              <!-- Card Header - Dropdown -->
              <?php 
                    //Xóa dữ liệu
              function resetId_S(){
                global $dbh;
                $sql = "ALTER TABLE dkyhoc AUTO_INCREMENT = 1";
                $statement = $dbh->prepare($sql);
                $statement->execute();
                $statement->closeCursor();

              }
              function resetDB_S(){
                global $dbh;

                $sql = "delete from dkyhoc";
                $statement = $dbh->prepare($sql);
                $statement->execute();
                $statement->closeCursor();

              }
              ?>
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Register to study</h6>
                <div class="dropdown no-arrow">
                  <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                  </a>
                  <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                    <form action="" method="post">
                      <button type="submit" class="dropdown-item" name="resetS">Reset</button> 
                    </form>
                    <?php 
                    if (isset($_POST['resetS'])) {
                      resetId_S();resetDB_S();
                    }
                    ?>
                  </div>
                </div>
              </div>
              <!-- Card Body -->
              <div class= "table-sm">
                <?php 
                try {
                  $sql = "Select * from dkyhoc";
                  $statement = $dbh->prepare($sql);
                          $ch = $statement->execute(); //ch = true or false
                          if (!$ch) {
                           print_r($statement->errorInfo());
                           exit();
                         }
                         $registers = $statement->fetchAll(); //lấy ra tất cả lop 
                         $statement->closeCursor();

                         $page = "<h3 class='display-6' style='text-align: center;'>Danh sách đăng ký học</h3>";
                         $page .= "<table class='table table-striped'  style='width: 100%;'>";
                         $page .="<thead >";
                         $page .="<tr id='list-header'>";
                         $page .="<th scope='col'>STT</th>";
                         $page .="<th scope='col'>Họ tên</th>";
                         $page .="<th scope='col'>SĐT</th>";
                         $page .="<th scope='col'>Email</th>";
                         $page .="</tr>";
                         $page .="</thead>";  
                         $page .="<tbody>";  
                         foreach ($registers as $key => $value) {
                           $page .= '<td>' . $value['id'] . '</td>';
                           $page .= '<td>' . $value['hoten'] . '</td>';
                           $page .= '<td>' . $value['sdt'] . '</td>';
                           $page .= '<td>' . $value['email'] . '</td>';
                           $page .= '</tr>';
                         }
                         $page .="</tbody>";
                         $page .= '</table>';
                         echo $page;
                       } catch (Exception $e) {
                        print_r($e->getMessage());
                      }



                      ?>

                    </div>
                  </div>
                </div>

                <!-- Pie Chart -->
                <div class="col-xl-6 col-lg-5">
                  <div class="card shadow mb-4">
                    <!-- Card Header - Dropdown -->
                    <?php 
                    //Xóa dữ liệu
                    function resetId_C(){
                      global $dbh;
                      $sql = "ALTER TABLE dkylop AUTO_INCREMENT = 1";
                      $statement = $dbh->prepare($sql);
                      $statement->execute();
                      $statement->closeCursor();

                    }
                    function resetDB_C(){
                      global $dbh;

                      $sql = "delete from dkylop";
                      $statement = $dbh->prepare($sql);
                      $statement->execute();
                      $statement->closeCursor();

                    }
                    ?>
                    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                      <h6 class="m-0 font-weight-bold text-primary">Class registration</h6>
                      <div class="dropdown no-arrow">
                        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                          <form action="" method="post">
                            <button type="submit" class="dropdown-item" name="resetC">Reset</button> 
                          </form>
                        </div>
                        <?php 
                        if (isset($_POST['resetC'])) {
                          resetId_C();resetDB_C();
                        }
                        ?>
                      </div>
                    </div>
                    <!-- Card Body -->
                    <div class="table-sm">
                     <?php 
                     try {
                      $sql_c = "Select * from dkylop join lophoc on dkylop.malop = lophoc.malop";
                      $statement_c = $dbh->prepare($sql_c);
                          $ch = $statement_c->execute(); //ch = true or false
                          if (!$ch) {
                           print_r($statement_c->errorInfo());
                           exit();
                         }
                         $registers = $statement_c->fetchAll(); //lấy ra tất cả lop 
                         $statement_c->closeCursor();

                         $page = "<h3 class='display-6' style='text-align: center;'>Danh sách đăng ký lớp</h3>";
                         $page .= "<table class='table table-striped'  style='width: 100%;'>";
                         $page .="<thead >";
                         $page .="<tr id='list-header'>";
                         $page .="<th scope='col'>STT</th>";
                         $page .="<th scope='col'>Tên Lớp</th>";
                         $page .="<th scope='col'>Họ tên</th>";
                         $page .="<th scope='col'>SĐT</th>";
                         $page .="<th scope='col'>Email</th>";
                         $page .="</tr>";
                         $page .="</thead>";  
                         $page .="<tbody>";  
                         foreach ($registers as $key => $value) {
                           $page .= '<td>' . $value['id'] . '</td>';
                           $page .= '<td>' . $value['tenlop'] . '</td>';
                           $page .= '<td>' . $value['hoten'] . '</td>';
                           $page .= '<td>' . $value['sdt'] . '</td>';
                           $page .= '<td>' . $value['email'] . '</td>';
                           $page .= '</tr>';
                         }
                         $page .="</tbody>";
                         $page .= '</table>';
                         echo $page;
                       } catch (Exception $e) {
                        print_r($e->getMessage());
                      }


                      ?>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Content Row -->
              <div class="row">

                <!-- Content Column -->
                <div class="col-lg-12 mb-6">

                  <!-- Project Card Example -->
                  <div class="card shadow mb-4">
                    <div class="card-header py-3">
                      <h6 class="m-0 font-weight-bold text-primary">Thống kê</h6>
                    </div>
                    <div class="table-sm">
                      <form action="" method="post">
                        <table class="table-striped">
                          <tr>
                            <th><select name="namhoc">
                              <option value="">--Năm--</option>
                              <option value="2019">2019</option>
                              <option value="2020">2020</option>
                              <option value="2021">2021</option>
                            </select></th>
                            <th><button type="submit" name="show" class="btn-secondary">Hiển thị</button></th>
                          </tr>
                          <tr>
                            <td>
                              <?php
                              if (isset($_POST['namhoc'])) {
                                $namhoc = $_POST['namhoc'];
                                echo "Năm học: $namhoc";
                              }else
                              echo "Năm học: ".date('Y'); ?></td>
                            </tr>
                            <tr>
                              <td>
                                <?php
                                if (isset($_POST['namhoc'])) {
                                  $namhoc = $_POST['namhoc'];
                                  $sum = tongHs($namhoc);
                                  echo "Tổng số học sinh:". $sum['sum_st'];
                                }else{
                                  $sum = tongHs(date('Y'));
                                  echo "Tổng số học sinh:". $sum['sum_st'];
                                }
                                ?>
                              </td>
                            </tr>
                          </table>
                        </form>
                      </div>
                      <?php 
                      function thongke($namhoc, $quy)
                      {
                        global $dbh;
                        $sql_st = "select  count(distinct mahs) as sum_st from hocsinh join lophoc on hocsinh.malop = lophoc.malop join lichhoc on lichhoc.malop = lophoc.malop
                        where quy = :quy and namhoc = :namhoc" ;
                        $statement = $dbh->prepare($sql_st);
                        $statement->bindvalue(':quy', $quy);
                        $statement->bindvalue(':namhoc', $namhoc);
                        $statement->execute();
                        $sum_st = $statement->fetch(); 
                        $statement->closecursor(); 
                        return $sum_st; 
                      }

                    //Tổng hs
                      function tongHs($namhoc)
                      {
                        global $dbh;
                        $sql_st = "select  count(distinct mahs) as sum_st from hocsinh join lophoc on hocsinh.malop = lophoc.malop join lichhoc on lichhoc.malop = lophoc.malop
                        where namhoc = :namhoc" ;
                        $statement = $dbh->prepare($sql_st);

                        $statement->bindvalue(':namhoc', $namhoc);
                        $statement->execute();
                        $sum_st = $statement->fetch(); 
                        $statement->closecursor(); 
                        return $sum_st; 
                      }


                      ?>
                      <div class="card-body">
                        <h4 class="small font-weight-bold">QUÝ 1<span class="float-right">
                          <?php 

                          if (isset($_POST['show'])) {
                            $namhoc = $_POST['namhoc'];
                            $thongke = thongke($namhoc, 1);
                            $sum = tongHs($namhoc);
                            if($thongke['sum_st'] == "" || $sum['sum_st'] == 0){
                              echo "0";
                              $pt = 0;
                            }
                            else {
                              echo $thongke['sum_st'];
                              $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                            }
                          }
                          else{ 
                            $thongke = thongke(date('Y'), 1);
                            $sum = tongHs(date('Y'));
                            if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                              echo "0";
                              $pt = 0;
                            }
                            else {
                              echo $thongke['sum_st'];
                              $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                            }

                          }

                          ?> Học sinh
                        </span></h4>

                        <div class="progress mb-4">
                          <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo $pt; ?>%;" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        <h4 class="small font-weight-bold">QUÝ 2 <span class="float-right">
                         <?php 
                         if (isset($_POST['show'])) {
                          $namhoc = $_POST['namhoc'];
                          $thongke = thongke($namhoc, 2);
                          $sum = tongHs($namhoc);
                          if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                            echo "0";
                            $pt = 0;
                          }
                          else {
                            echo $thongke['sum_st'];
                            $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                          }
                        }else{ 
                          $thongke = thongke(date('Y'), 2);
                          $sum = tongHs(date('Y'));
                          if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                            echo "0";
                            $pt = 0;
                          }
                          else {
                            echo $thongke['sum_st'];
                            $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                          }
                        }
                        ?> Học sinh
                      </span></h4>
                      <div class="progress mb-4">
                        <div class="progress-bar bg-warning" role="progressbar" style="width: <?php echo $pt; ?>%;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <h4 class="small font-weight-bold">QUÝ 3 <span class="float-right">
                       <?php 
                       if (isset($_POST['show'])) {
                        $namhoc = $_POST['namhoc'];
                        $thongke = thongke($namhoc,3);
                        $sum = tongHs($namhoc);
                        if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                          echo "0";
                          $pt = 0;
                        }
                        else {
                          echo $thongke['sum_st'];
                          $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                        }
                      }else{ 
                        $thongke = thongke(date('Y'), 3);
                        $sum = tongHs(date('Y'));
                        if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                          echo "0";
                          $pt = 0;
                        }
                        else {
                          echo $thongke['sum_st'];
                          $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                        }
                      }
                      ?> Học sinh
                    </span></h4>
                    <div class="progress mb-4">
                      <div class="progress-bar" role="progressbar" style="width: <?php echo $pt; ?>%;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <h4 class="small font-weight-bold">QUÝ 4 <span class="float-right">
                     <?php 
                     if (isset($_POST['show'])) {
                      $namhoc = $_POST['namhoc'];
                      $thongke = thongke($namhoc, 4 );
                      $sum = tongHs($namhoc);
                      if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                        echo "0";
                        $pt = 0;
                      }
                      else {
                        echo $thongke['sum_st'];
                        $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                      }
                    }else{ 
                      $thongke = thongke(date('Y'), 4);
                      $sum = tongHs(date('Y'));
                      if($thongke['sum_st'] == ""  || $sum['sum_st'] == 0){
                        echo "0";
                        $pt = 0;
                      }
                      else {
                        echo $thongke['sum_st'];
                        $pt = ($thongke['sum_st']/$sum['sum_st'])*100;
                      }
                    }
                    ?> Học sinh
                  </span></h4>
                  <div class="progress mb-4">
                    <div class="progress-bar bg-info" role="progressbar" style="width: <?php echo $pt; ?>%;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../js/demo/chart-area-demo.js"></script>
  <script src="../js/demo/chart-pie-demo.js"></script>

</body>

</html>
<?php ob_end_flush();  $dbh=null;?>
