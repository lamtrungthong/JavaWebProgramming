
create database if not exists ttta;
use ttta;

CREATE TABLE if not exists `giaovien` (
  `magv` varchar(10) NOT NULL primary key,
  `tengv` varchar(45) NOT NULL,
  `tuoi` int(11) NOT NULL,
  `gioitinh` varchar(3) DEFAULT 'nam',
  `sdt` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  `anh` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE  if not exists `khoa` (
  `makhoa` varchar(10) NOT NULL primary key,
  `tenkhoa` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `lophoc` (
  `malop` varchar(10) ,
  `tenlop` varchar(45),
  `magv` varchar(10) ,
  `makhoa` varchar(10) ,
  `siso` int(11) NOT NULL,
  `ghichu` varchar(255),
  primary key (malop, magv ),
  foreign key (magv) references giaovien(magv) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `lichhoc` (
  `malop` varchar(10) NOT NULL,
  `khaigiang` date NOT NULL,
  `quy` int(11) DEFAULT NULL,
  `buoi` varchar(5) DEFAULT NULL,
  `thu` varchar(10) NOT NULL,
  `begiang` date NOT NULL,
  `namhoc` int(11) NOT NULL,
  primary key (malop,thu),
  foreign key (malop) references lophoc(malop) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE  if not exists `hocsinh` (
  `mahs` varchar(10) NOT NULL,
  `malop` varchar(10) NOT NULL,
  `tenhs` varchar(45) NOT NULL,
  `tuoi` int(11) NOT NULL,
  `gioitinh` varchar(3) DEFAULT 'nam',
  `sdt` varchar(10) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `diachi` varchar(255) NOT NULL,
  primary key (mahs, malop),
  foreign key (malop) references lophoc(malop) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;



CREATE TABLE  if not exists `luonggv` (
  `magv` varchar(10) NOT NULL primary key,
  `luongcb` int(11) NOT NULL,
  `ngaycong` int(11) NOT NULL,
  `trocap` int(11) NOT NULL,
  `thuong` int(11) DEFAULT NULL,
  foreign key (magv) references giaovien (magv) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `phuhuynh` (
  `maph` varchar(10) NOT NULL,
  `mahs` varchar(10) NOT NULL,
  `tenph` varchar(45) NOT NULL,
  `sdt` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `diachi` varchar(255) NOT NULL,
  primary key ( maph, mahs),
  foreign key (mahs) references hocsinh (mahs) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `usergv` (
  `magv` varchar(10) NOT NULL primary key,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  foreign key (magv) references giaovien(magv) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `userhs` (
  `mahs` varchar(20) NOT NULL primary key,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  foreign key (mahs) references hocsinh (mahs) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

CREATE TABLE if not exists `userph` (
  `maph` varchar(10) NOT NULL primary key,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  foreign key (maph) references phuhuynh (maph) on delete cascade
) ENGINE=InnoDB DEFAULT CHARACTER SET=utf8;

INSERT INTO `khoa` (`makhoa`, `tenkhoa`) VALUES
('NN', 'KhÃ³a giao tiáº¿p'),
('S', 'KhÃ³a Starter'),
('TC', 'KhÃ³a 4 kÄ© nÄƒng');

INSERT INTO `giaovien` (`magv`, `tengv`, `tuoi`, `gioitinh`, `sdt`, `email`, `diachi`, `anh`) VALUES
('GV13229', 'Jang Nana', 32, 'NÆ°', '0888899999', 'jangnana@gmail.com', 'HÃ   Ná»™i', 'nana.jpg'),
('GV21950', 'Tráº§n Nguyá»…n Minh Nghi', 23, 'NÆ°', '0887651234', 'minhnghitn@gmail.com', 'HÃ   Ná»™i', 'minhnghi.jpg'),
('GV62250', 'BÃ¹i Trá»¥ Hiá»‡n', 24, 'NÆ°', '0987654321', 'Hienbt@gmail.com', 'HÃ  Ná»™i', 'hienbt.jpg'),
('GV76142', 'LÆ°u HÃ²a  BÃ¬nh', 24, 'Nam', '0999999999', 'binhlh@gmail.com', 'HÃ   Ná»™i', 'hoabinh.jpg'),
('GV78583', 'Chris Evans', 28, 'Nam', '0988886666', 'chrisevans@gmail.com', 'HÃ   Ná»™i', 'evans.jpg'),
('GV90804', 'Nguyá»…n Thá»‹ Thá»§y', 26, 'NÆ°', '0888888888', 'thuynt@gmail.com', 'HÃ   Ná»™i', 'sachi.jpg');