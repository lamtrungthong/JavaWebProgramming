<!DOCSTYPE html>
<html>

<body>
<?php
include "Admin/connectdb.php";
function isTeachlogin(){
	
	if (isset($_SESSION['user_teacher'])) {
		
		return true;
	} else 
		return false;
}
function getNameTeach($magv){
	global $dbh;
	$query = 'SELECT tengv FROM giaovien  WHERE magv = :magv';
		$statement = $dbh->prepare($query);
		$statement->bindValue(':magv', $magv);
		$statement->execute();
		$teacher = $statement->fetch(); 
		$statement->closeCursor();
		return $teacher;
}
?>
</body>
</html>