<!DOCSTYPE html>
<html>

<body>
<?php
include "Admin/connectdb.php";
function isStlogin(){
	
	if (isset($_SESSION['user_student'])) {
		
		return true;
	} else 
		return false;
}
function getNameSt($mahs){
	global $dbh;
	$query = 'SELECT tenhs FROM hocsinh  WHERE mahs = :mahs';
		$statement = $dbh->prepare($query);
		$statement->bindValue(':mahs', $mahs);
		$statement->execute();
		$student = $statement->fetch(); //lấy ra 1 student
		$statement->closeCursor();
		return $student;
}
?>
</body>
</html>