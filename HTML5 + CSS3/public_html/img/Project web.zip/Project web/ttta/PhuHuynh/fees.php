<!DOCTYPE html>
<html>
<?php 
ob_start();
session_start();
require '../Admin/connectdb.php';
require '../islogin.php';
require '../isStlogin.php';
require '../isParLogin.php';
require '../isTeachLogin.php';
?>
<?php
if(isParlogin()){
	//Thông tin học sinh
	$maph =  $_SESSION["user_parent"];
	$sql = "select distinct hocsinh.mahs, tenhs from phuhuynh join hocsinh 
	on phuhuynh.mahs = hocsinh.mahs where maph = :maph";
	$statement = $dbh->prepare($sql);
	$statement->bindValue(':maph', $maph);
	$statement->execute();
	$parents = $statement->fetchAll();
	$statement->closeCursor();

	$sql2 = "select distinct tenph  from phuhuynh where maph = :maph";
	$statement2 = $dbh->prepare($sql2);
	$statement2->bindValue(':maph', $maph);
	$statement2->execute();
	$parent = $statement2->fetch();
	$statement2->closeCursor();
	
	$tenph = $parent['tenph'];


	//học phí
	function getFee($mahs){
		global $dbh;
		$sql = "select * from hocphi join hocphi_hocsinh on hocphi.makhoa = hocphi_hocsinh.makhoa 
		join lophoc on lophoc.malop = hocphi_hocsinh.malop
		where mahs = :mahs";
		$statement = $dbh->prepare($sql);
		$statement->bindValue(':mahs', $mahs);
		$statement->execute();
		$fees = $statement->fetchAll(); 
		$statement->closeCursor();
		return $fees;
	}
}else{
	echo "<h3>Bạn chưa đăng nhập</h3>";
	echo "<a href=../../login.php>Click vào đây để đăng nhập</a><br>";
}

?>
<title>Học phí</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="">

<title>English Center</title>
<!-- Custom fonts for this template-->
<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<!-- Custom fonts for this template -->
<link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href='https://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700' rel='stylesheet' type='text/css'>
<!-- Bootstrap core JavaScript -->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Contact form JavaScript -->
<script src="../js/jqBootstrapValidation.js"></script>
<script src="../js/contact_me.js"></script>

<!-- Custom scripts for this template -->
<script src="../js/agency.min.js"></script>

<!-- Custom styles for this template -->
<link href="../css/agency.min.css" rel="stylesheet">
<link href="./css/style.css" rel="stylesheet">
</head>
<body id="page-top">
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark fixed-top " style="background-color:black; height: 60px" id="mainNav">
		<div class="container">
			<a class="navbar-brand js-scroll-trigger" href="../index.php">English Center</a>
			<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				Menu
				<i class="fas fa-bars"></i>
			</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav text-uppercase ml-auto">
					<!--Profile  -->
					<?php
					if (isParlogin() == true) {
						$parent = getNamePar($_SESSION['user_parent']);
						echo "<li class='nav-item dropdown no-arrow'>";
						echo "<a class='nav-link dropdown-toggle' href='#'' id='userDropdown' role='button' data-toggle='dropdown' aria-haspopup= true aria-expanded= false >";
						echo "<span class= 'mr-2 d-none d-lg-inline text-white-600 lg'>".$parent['tenph'] ."</span>";
						echo "<img class='img-profile rounded-circle' src='../img/profile.png' width='20' height= 20 >
						</a>
						<div class= 'dropdown-menu dropdown-menu-right shadow animated--grow-in' aria-labelledby='userDropdown'>
						<a class= 'dropdown-item' href='profile.php'>
						<i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
						Thông tin cá nhân
						</a>
						<a class= 'dropdown-item' href='profileSt.php'>
						<i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
						Thông tin học sinh
						</a>
						<a class= 'dropdown-item' href='fees.php'>
						<i class='fas fa-user fa-sm fa-fw mr-2 text-black-200'></i>
						Thông tin học phí
						</a>
						<a class='dropdown-item' href= '#' data-toggle= modal  data-target= '#logoutModal'>
						<i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-black-200'></i>
						Logout
						</a>
						</div>
						</li>"; 
					}
					else{
						echo "<li class='nav-item'>
						<a href='login.php'>
						<button type='button' class='btn btn-primary' style='margin-left:50px ;margin-top:5px'>Đăng nhập</button>
						</a>
						</li>";
					}

					?>
				</ul>
			</div>
		</div>
	</nav>
	<!-- Logout Modal-->
	<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
					<button class="close" type="button" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">×</span>
					</button>
				</div>
				<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
				<div class="modal-footer">
					<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
					<a class="btn btn-primary" href="../logout.php">Logout</a>
				</div>
			</div>
		</div>
	</div>
	<div id="slides" class="carousel slide" data-ride="carousel">
		<?php
		$sql = "select anh from quangcao";
		$statement = $dbh->prepare($sql);
		$statement->execute();
		$anhs = $statement->fetchAll();
		$statement->closeCursor();
		echo "<ul class='carousel-indicators'>";
		for($i = 0; $i< count($anhs) ; $i++) {    
			if($i == 0){
				echo "<li data-target= #slides data-slide-to=".$i." class= active></li>";
			}else{
				echo "<li data-target= #slides data-slide-to=". $i."></li>";
			}

		}
		echo "</ul>";

		?>
		<div class="carousel-inner">
			<?php
			for($i = 0; $i< count($anhs) ; $i++){
				if ($i == 0) {
					echo "<div class='carousel-item active' >";
					echo "<img src=../img/".$anhs[$i]['anh']." width = 100% height = 800px >";
					echo "</div>";
				}
				else {
					echo "<div class='carousel-item ' >";
					echo "<img src=../img/".$anhs[$i]['anh']." width = 100% height = 800px >";
					echo "</div>";
				}
			}
			?>
		</div>
	</div>

	<div>
		<div id = "title">
			<h2></h2>
		</div>

		<div id = "content">
			<?php 
			if(isParlogin()){
				foreach($parents as $student){

					$fees = getFee($student['mahs']);
					$hocphi = "<h1 class='display-4 my-4 text-info'>Thông tin học phí</h1>";
					$hocphi .= "<h4>Học sinh: ". $student['tenhs'] ." - " .$student['mahs'] . "</h4>"; 
					$hocphi .= "<table class='table table-striped' style='width: 100%;'>";
					$hocphi .="<thead >";
					$hocphi .="<tr id='list-header'>";
					$hocphi .="<th scope='col'>STT</th>";
					$hocphi .="<th scope='col'>Lớp học</th>";
					$hocphi .="<th scope='col'>Học phí</th>";
					$hocphi .="<th scope='col'>Giảm giá</th>";
					$hocphi .="<th scope='col'>Phải đóng</th>";
					$hocphi .="<th scope='col'>Đã đóng</th>";
					$hocphi .="<th scope='col'>Còn phải đóng</th>";
					$hocphi .="</tr>";
					$hocphi .="</thead>";  
					$hocphi .="<tbody>";  
					$stt = 1; 
					foreach($fees as $fee){
						$realfee = $fee['hocphi'] - $fee['hocphi']*$fee['giamgia']/100;
						$phaidong = $realfee - $fee['dadong'];
						$hocphi .= "<tr>"; 
						$hocphi .= "<td>$stt</td><td>" . $fee['tenlop'] . "</td><td>".$fee['hocphi']." VND</td><td>".$fee['giamgia']." %</td>";
						$hocphi .="</td><td>".$realfee." VND</td><td>".$fee['dadong']." VND</td><td><div id = realfee >".$phaidong." VND</div></td> </tr>";
						$stt++;
					}

					$hocphi .="</tbody>"; 
					$hocphi .=  "</table>";
					echo $hocphi;
				}
			}
			?>
		</div> 
	</div>
	<section class="page-section background-color: white">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8 text-center">
					<h2 class="mt-0">ENGLISH CENTER!</h2>
					<hr class="divider my-4">
					<b class="text-muted mb-5">Cơ quan chủ quản: Học viện Kỹ thuật Mật mã</b>
					<p class="text-muted mb-5">Giám Đốc Trung Tâm: Lê Đức Thuận.</p>
					<p class="text-muted mb-5">Địa chỉ: 141 đường Chiến Thắng, Tân Triều, Thanh Trì, Hà Nội.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
					<i class="fas fa-phone fa-3x mb-3 text-muted"></i>
					<div>0962275585</div>
				</div>
				<div class="col-lg-4 mr-auto text-center">
					<i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
					<!-- Make sure to change the email address in anchor text AND the link below! -->
					<div>nnkma@gmail.com</div>
				</div>
				<div class="col-lg-4 ml-auto text-center mb-5 mb-lg-0">
					<i class="fab fa-facebook-f fa-3x mb-3 text-muted"></i>
					<a class="d-block" href="https://www.facebook.com/kma.trungtamngoaingu">Facebook</a>
				</div>

			</div>
		</section>
	</body>
	</html>