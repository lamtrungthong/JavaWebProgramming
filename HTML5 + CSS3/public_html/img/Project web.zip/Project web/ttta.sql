-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2019 at 11:29 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ttta`
--

-- --------------------------------------------------------

--
-- Table structure for table `diemdanh`
--

CREATE TABLE `diemdanh` (
  `mahs` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `dahoc` int(11) DEFAULT NULL,
  `danghi` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `diemdanh`
--

INSERT INTO `diemdanh` (`mahs`, `malop`, `dahoc`, `danghi`) VALUES
('HS17160', 'TC.9.3.1', 0, 0),
('HS23640', 'S.9.1.4', 0, 0),
('HS23879', 'NN.9.3.1', 0, 1),
('HS24215', 'S.9.3.1', 0, 0),
('HS27050', 'NN.9.3.1', 0, 1),
('HS29863', 'S.9.1.4', 0, 0),
('HS30202', 'TC.9.2.4', 0, 0),
('HS32638', 'S.9.3.1', 0, 0),
('HS35335', 'TC.9.2.4', 0, 0),
('HS35994', 'S.9.3.1', 0, 0),
('HS39108', 'TC.9.3.1', 0, 0),
('HS39737', 'TC.9.2.4', 0, 0),
('HS41091', 'TC.9.3.1', 0, 0),
('HS42192', 'S.9.1.4', 0, 0),
('HS42879', 'NN.9.3.1', 1, 0),
('HS42955', 'NN.9.3.1', 1, 0),
('HS44984', 'NN.9.3.1', 1, 0),
('HS49492', 'TC.9.3.1', 0, 0),
('HS49690', 'S.9.3.1', 0, 0),
('HS50629', 'S.9.1.4', 0, 0),
('HS53472', 'TC.9.2.4', 0, 0),
('HS58013', 'TC.9.3.1', 0, 0),
('HS60356', 'NN.9.3.1', 1, 0),
('HS61507', 'NN.9.3.1', 1, 0),
('HS63704', 'TC.9.3.1', 0, 0),
('HS64925', 'S.9.3.1', 0, 0),
('HS65356', 'NN.9.3.1', 1, 0),
('HS67046', 'S.9.3.1', 0, 0),
('HS67336', 'S.9.1.4', 0, 0),
('HS67488', 'TC.9.2.4', 0, 0),
('HS70111', 'S.9.1.4', 0, 0),
('HS71223', 'S.9.3.1', 0, 0),
('HS72162', 'S.9.3.1', 0, 0),
('HS73046', 'TC.9.2.4', 0, 0),
('HS73413', 'TC.9.3.1', 0, 0),
('HS74183', 'S.9.1.4', 0, 0),
('HS75379', 'NN.9.3.1', 1, 0),
('HS77552', 'TC.9.2.4', 0, 0),
('HS80015', 'S.9.3.1', 0, 0),
('HS81285', 'S.9.1.4', 0, 0),
('HS82256', 'TC.9.2.4', 0, 0),
('HS84353', 'TC.9.3.1', 0, 0),
('HS85316', 'TC.9.3.1', 0, 0),
('HS85687', 'S.9.1.4', 0, 0),
('HS85788', 'S.9.3.1', 0, 0),
('HS88077', 'NN.9.3.1', 1, 0),
('HS95803', 'TC.9.3.1', 0, 0),
('HS98366', 'S.9.1.4', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dkyhoc`
--

CREATE TABLE `dkyhoc` (
  `id` int(11) NOT NULL,
  `hoten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dkyhoc`
--

INSERT INTO `dkyhoc` (`id`, `hoten`, `email`, `sdt`) VALUES
(1, 'Giáp Văn Thọ', 'thogiap98@gmail.com', '0339276789');

-- --------------------------------------------------------

--
-- Table structure for table `dkylop`
--

CREATE TABLE `dkylop` (
  `id` int(11) NOT NULL,
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `hoten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `dkylop`
--

INSERT INTO `dkylop` (`id`, `malop`, `hoten`, `sdt`, `email`) VALUES
(1, 'NN.9.4.2', 'Giáp Văn Thọ', '0339276789', 'thogiap98@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `giaovien`
--

CREATE TABLE `giaovien` (
  `magv` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tengv` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `tuoi` int(11) NOT NULL,
  `gioitinh` varchar(3) COLLATE utf8_unicode_ci DEFAULT 'nam',
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `diachi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `anh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `giaovien`
--

INSERT INTO `giaovien` (`magv`, `tengv`, `tuoi`, `gioitinh`, `sdt`, `email`, `diachi`, `anh`) VALUES
('GV13229', 'Jang Nana', 32, 'Nam', '0888899999', 'jangnana@gmail.com', 'Hà Nội', 'nana.jpg'),
('GV21950', 'Trần Nguyễn Minh Nghi', 23, 'Nữ', '0887651234', 'minhnghitn@gmail.com', 'Hà Nội', 'minhnghi.jpg'),
('GV62250', 'Bùi Trụ Hiền', 24, 'Nữ', '0987654321', 'Hienbt@gmail.com', 'Hà Nội', 'hienbt.jpg'),
('GV76142', 'Lưu Hòa Bình', 24, 'Nam', '0999999999', 'binhlh@gmail.com', 'Hà Nội', 'hoabinh.jpg'),
('GV78583', 'Chris Evans', 28, 'Nam', '0988886666', 'chrisevans@gmail.com', 'Hà Nội', 'evans.jpg'),
('GV90804', 'Nguyễn Thị Thủy', 26, 'Nữ', '0888888888', 'thuynt@gmail.com', 'Nữ', 'sachi.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hocphi`
--

CREATE TABLE `hocphi` (
  `makhoa` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `hocphi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hocphi`
--

INSERT INTO `hocphi` (`makhoa`, `hocphi`) VALUES
('NN', 6000000),
('S', 8000000),
('TC', 9000000);

-- --------------------------------------------------------

--
-- Table structure for table `hocphi_hocsinh`
--

CREATE TABLE `hocphi_hocsinh` (
  `makhoa` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mahs` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `dadong` int(11) DEFAULT NULL,
  `giamgia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hocphi_hocsinh`
--

INSERT INTO `hocphi_hocsinh` (`makhoa`, `malop`, `mahs`, `dadong`, `giamgia`) VALUES
('NN', 'NN.9.3.1', 'HS23879', 5400000, 10),
('NN', 'NN.9.3.1', 'HS27050', 6000000, 0),
('NN', 'NN.9.3.1', 'HS42879', 5400000, 10),
('NN', 'NN.9.3.1', 'HS42955', 0, 0),
('NN', 'NN.9.3.1', 'HS44984', 4000000, 10),
('NN', 'NN.9.3.1', 'HS60356', 0, 0),
('NN', 'NN.9.3.1', 'HS61507', 0, 0),
('NN', 'NN.9.3.1', 'HS65356', 3000000, 0),
('NN', 'NN.9.3.1', 'HS75379', 0, 0),
('NN', 'NN.9.3.1', 'HS88077', 5400000, 10),
('S', 'S.9.1.4', 'HS23640', 7200000, 10),
('S', 'S.9.1.4', 'HS29863', 8000000, 0),
('S', 'S.9.1.4', 'HS42192', 7200000, 10),
('S', 'S.9.1.4', 'HS50629', 7200000, 10),
('S', 'S.9.1.4', 'HS67336', 8000000, 0),
('S', 'S.9.1.4', 'HS70111', 8000000, 0),
('S', 'S.9.1.4', 'HS74183', 7200000, 10),
('S', 'S.9.1.4', 'HS81285', 8000000, 0),
('S', 'S.9.1.4', 'HS85687', 8000000, 0),
('S', 'S.9.1.4', 'HS98366', 7200000, 10),
('S', 'S.9.3.1', 'HS24215', 4000000, 0),
('S', 'S.9.3.1', 'HS32638', 0, 0),
('S', 'S.9.3.1', 'HS35994', 0, 0),
('S', 'S.9.3.1', 'HS49690', 0, 0),
('S', 'S.9.3.1', 'HS64925', 0, 0),
('S', 'S.9.3.1', 'HS67046', 0, 0),
('S', 'S.9.3.1', 'HS71223', 0, 0),
('S', 'S.9.3.1', 'HS72162', 0, 0),
('S', 'S.9.3.1', 'HS80015', 0, 0),
('S', 'S.9.3.1', 'HS85788', 0, 0),
('TC', 'TC.9.2.4', 'HS30202', 9000000, 0),
('TC', 'TC.9.2.4', 'HS35335', 9000000, 0),
('TC', 'TC.9.2.4', 'HS39737', 8100000, 10),
('TC', 'TC.9.2.4', 'HS53472', 8100000, 10),
('TC', 'TC.9.2.4', 'HS67488', 9000000, 0),
('TC', 'TC.9.2.4', 'HS73046', 9000000, 0),
('TC', 'TC.9.2.4', 'HS77552', 9000000, 0),
('TC', 'TC.9.2.4', 'HS82256', 8100000, 10),
('TC', 'TC.9.3.1', 'HS17160', 0, 0),
('TC', 'TC.9.3.1', 'HS39108', 0, 0),
('TC', 'TC.9.3.1', 'HS41091', 0, 0),
('TC', 'TC.9.3.1', 'HS49492', 0, 0),
('TC', 'TC.9.3.1', 'HS58013', 0, 0),
('TC', 'TC.9.3.1', 'HS63704', 0, 0),
('TC', 'TC.9.3.1', 'HS73413', 0, 0),
('TC', 'TC.9.3.1', 'HS84353', 0, 0),
('TC', 'TC.9.3.1', 'HS85316', 0, 0),
('TC', 'TC.9.3.1', 'HS95803', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hocsinh`
--

CREATE TABLE `hocsinh` (
  `mahs` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tenhs` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `tuoi` int(11) NOT NULL,
  `gioitinh` varchar(3) COLLATE utf8_unicode_ci DEFAULT 'nam',
  `sdt` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `diachi` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hocsinh`
--

INSERT INTO `hocsinh` (`mahs`, `malop`, `tenhs`, `tuoi`, `gioitinh`, `sdt`, `email`, `diachi`) VALUES
('HS17160', 'TC.9.3.1', 'Lý Thị Ly', 18, 'Nam', '0995330736', 'lylt@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS23640', 'S.9.1.4', 'Hoàng Hải Hà', 21, 'Nam', '0927749439', 'hahh@gmail.com', 'Hà Đông, Hà Nội'),
('HS23879', 'NN.9.3.1', 'Lâm Văn Hải', 21, 'Nam', '0311189634', 'hailv@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS24215', 'S.9.3.1', 'Triệu lệ Dĩnh', 18, 'Nữ', '0344440380', 'dinhtl@gmail.com', 'Hà Đông, Hà Nội'),
('HS27050', 'NN.9.3.1', 'Nguyễn văn C', 18, 'Nam', '0369645195', 'nguyenC@gmail.com', 'Hà Đông, Hà Nội'),
('HS29863', 'S.9.1.4', 'Dương Hải Hiền', 21, 'Nam', '0934912642', 'hiendh@gmail.com', 'Hà Đông, Hà Nội'),
('HS30202', 'TC.9.2.4', 'Hoàng Thanh Đoàn', 21, 'Nữ', '0932566193', 'doanht@gmail.com', 'Hà Đông, Hà Nội'),
('HS32638', 'S.9.3.1', 'Vũ Duy Khánh', 18, 'Nam', '0988159958', 'khanhvd@gmail.com', 'Hà Đông, Hà Nội'),
('HS35335', 'TC.9.2.4', 'Giáp Thái Hậu', 19, 'Nữ', '0951059993', 'haugt@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS35994', 'S.9.3.1', 'Vũ Phát Tài', 21, 'Nam', '0340454059', 'taivp@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS39108', 'TC.9.3.1', 'Hoàng Hải Hậu', 21, 'Nam', '0385963734', 'hauhh@gmail.com', 'Hà Đông, Hà Nội'),
('HS39737', 'TC.9.2.4', 'Nguyễn Nhật Nam', 21, 'Nam', '0956257573', 'namnn@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS41091', 'TC.9.3.1', 'Vũ Hoàng Duy', 21, 'Nam', '0962266504', 'duyvh@gmail.com', 'Hà Đông, Hà Nội'),
('HS42192', 'S.9.1.4', 'Đinh Thị Thảo', 21, 'Nữ', '0980897704', 'thaodt12@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS42879', 'NN.9.3.1', 'Trần Thị Thủy', 19, 'Nữ', '0385581689', 'thuytt@gmail.com', 'Hà Đông, Hà Nội'),
('HS42955', 'NN.9.3.1', 'Hoàng Thị Ánh', 18, 'Nữ', '0392965691', 'anhht@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS44984', 'NN.9.3.1', 'Nguyễn văn B', 18, 'Nam', '0312798012', 'nguyenB@gmail.com', 'Hà Đông, Hà Nội'),
('HS49492', 'TC.9.3.1', 'Lâm Văn Tình', 21, 'Nam', '0967841405', 'tinhlv@gmail.com', 'Hà Đông, Hà Nội'),
('HS49690', 'S.9.3.1', 'Lương Thị Hoa', 18, 'Nữ', '0329937516', 'hoalt@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS50629', 'S.9.1.4', 'Huỳnh Phát La', 21, 'Nam', '0993624566', 'lahp@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS53472', 'TC.9.2.4', 'Nguyễn Trúc Nam', 21, 'Nam', '0944699456', 'namtn@gmail.com', 'Hà Đông, Hà Nội'),
('HS58013', 'TC.9.3.1', 'Huỳnh Trấn Thành', 21, 'Nam', '0988454646', 'thanhht@gmail.com', 'Hà Đông, Hà Nội'),
('HS60356', 'NN.9.3.1', 'Lý Văn Cao', 19, 'Nam', '0976545318', 'caolv@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS61507', 'NN.9.3.1', 'Lý Hoàng Hạnh', 21, 'Nữ', '0999919119', 'hanhhl@gmail.com', 'Hà Đông, Hà Nội'),
('HS63704', 'TC.9.3.1', 'Lâm Hồng Nhung', 18, 'Nữ', '0817204954', 'nhunglh@gmail.com', 'Hà Đông, Hà Nội'),
('HS64925', 'S.9.3.1', 'Lữ Văn Nghị', 21, 'Nam', '0347906523', 'nghilv@gmail.com', 'Hà Đông, Hà Nội'),
('HS65356', 'NN.9.3.1', 'Nguyễn văn D', 18, 'Nam', '0312173458', 'nguyenD@gmail.com', 'Hà Đông, Hà Nội'),
('HS67046', 'S.9.3.1', 'Đinh Quang Tuyển', 19, 'Nam', '0964532621', 'tuyendq@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS67336', 'S.9.1.4', 'Thái Thanh Hậu', 21, 'Nữ', '0995548382', 'hautt@gmail.com', 'Hà Đông, Hà Nội'),
('HS67488', 'TC.9.2.4', 'Lê Thị Ánh', 21, 'Nữ', '0918531264', 'anhlt@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS70111', 'S.9.1.4', 'Đào Thùy Dung', 21, 'Nữ', '0951992022', 'dungdt@gmail.com', 'Hà Đông, Hà Nội'),
('HS71223', 'S.9.3.1', 'Hoàng Thị Nguyệt', 21, 'Nữ', '0962864778', 'nguyetht@gmail.com', 'Hà Đông, Hà Nội'),
('HS72162', 'S.9.3.1', 'Hoàng Hoa Thám', 21, 'Nam', '0952842162', 'thamhh@gmail.com', 'Hà Đông, Hà Nội'),
('HS73046', 'TC.9.2.4', 'Đàm Minh Hiếu', 21, 'Nam', '0926262975', 'hieudm@gmail.com', 'Hà Đông, Hà Nội'),
('HS73413', 'TC.9.3.1', 'Lữ  Hồng Nhung', 21, 'Nữ', '0950268032', 'nhunglh36@gmail.com', 'Hà Đông, Hà Nội'),
('HS74183', 'S.9.1.4', 'Nguyễn Nhật Anh', 21, 'Nam', '0977309640', 'anhnn@gmail.com', 'Hà Đông, Hà Nội'),
('HS75379', 'NN.9.3.1', 'Phùng Thị Kim', 18, 'Nữ', '0383973333', 'kimpt@gmail.com', 'Hà Đông, Hà Nội'),
('HS77552', 'TC.9.2.4', 'Đình Hải Hòa', 21, 'Nam', '0966633257', 'hoadh@gmail.com', 'Hà Đông, Hà Nội'),
('HS80015', 'S.9.3.1', 'Hoàng Văn Thái', 21, 'Nam', '0349172360', 'thaihv@gmail.com', 'Hà Đông, Hà Nội'),
('HS81285', 'S.9.1.4', 'Phan Hoàng Yến', 19, 'Nữ', '0956911705', 'yenph@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS82256', 'TC.9.2.4', 'Lý Thị Hạnh', 21, 'Nữ', '0391349400', 'hanhlt@gmail.com', 'Hà Đông, Hà Nội'),
('HS84353', 'TC.9.3.1', 'Lã Xuân Dương', 21, 'Nam', '0986738270', 'duonglx@gmail.com', 'Hà Đông, Hà Nội'),
('HS85316', 'TC.9.3.1', 'Huỳnh Thái Châu', 21, 'Nam', '0944440380', 'chauht@gmail.com', 'Hà Đông, Hà Nội'),
('HS85687', 'S.9.1.4', 'Lưu Văn Linh', 21, 'Nam', '0949123211', 'linhlv@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS85788', 'S.9.3.1', 'Lữ Quốc Tuấn', 21, 'Nam', '0384873116', 'tuanql@gmail.com', 'Hà Đông, Hà Nội'),
('HS88077', 'NN.9.3.1', 'Nguyễn văn A', 18, 'Nam', '0392323456', 'nguyenA@gmail.com', 'Hà Đông, Hà Nội'),
('HS95803', 'TC.9.3.1', 'Đặng Đình Đạt', 21, 'Nam', '0982346656', 'datdd@gmail.com', 'Thanh Xuân, Hà Nội'),
('HS98366', 'S.9.1.4', 'Đặng Tuấn Anh', 21, 'Nam', '0932022646', 'anhdt@gmail.com', 'Hà Đông, Hà Nội');

-- --------------------------------------------------------

--
-- Table structure for table `khoa`
--

CREATE TABLE `khoa` (
  `makhoa` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tenkhoa` varchar(45) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khoa`
--

INSERT INTO `khoa` (`makhoa`, `tenkhoa`) VALUES
('NN', 'Khóa giao tiếp'),
('S', 'Khóa Starter'),
('TC', 'Khóa 4 kỹ năng');

-- --------------------------------------------------------

--
-- Table structure for table `lichhoc`
--

CREATE TABLE `lichhoc` (
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `khaigiang` date NOT NULL,
  `quy` int(11) DEFAULT NULL,
  `buoi` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thu` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `begiang` date NOT NULL,
  `namhoc` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lichhoc`
--

INSERT INTO `lichhoc` (`malop`, `khaigiang`, `quy`, `buoi`, `thu`, `begiang`, `namhoc`) VALUES
('NN.9.3.1', '2019-06-01', 3, 'Sáng', 'Thứ 2, Thứ 3', '2019-09-01', 2019),
('NN.9.4.2', '2019-09-01', 4, 'Sáng', 'Thứ 2, Thứ 3', '2019-12-31', 2019),
('S.9.1.4', '2019-01-31', 1, 'Sáng', 'Thứ 4, Thứ 5', '2019-03-31', 2019),
('S.9.3.1', '2019-06-02', 3, 'Chiều', 'Thứ 5, Thứ 6', '2019-08-02', 2019),
('S.9.3.2', '2019-07-01', 3, 'Chiều', 'Thứ 7, Chủ nhật', '2019-09-02', 2019),
('TC.9.2.4', '2019-03-01', 2, 'Chiều', 'Thứ 4, Thứ 5', '2019-05-31', 2019),
('TC.9.3.1', '2019-06-06', 3, 'Tối', 'Thứ 7, Chủ nhật', '2019-10-01', 2019),
('TC.9.4.2', '2019-08-01', 4, 'Tối', 'Thứ 4, Thứ 5', '2019-11-30', 2019);

-- --------------------------------------------------------

--
-- Table structure for table `lophoc`
--

CREATE TABLE `lophoc` (
  `malop` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tenlop` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `magv` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `makhoa` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `siso` int(11) NOT NULL,
  `ghichu` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `lophoc`
--

INSERT INTO `lophoc` (`malop`, `tenlop`, `magv`, `makhoa`, `siso`, `ghichu`) VALUES
('NN.9.3.1', 'Khóa giao tiếp NN.9.3.1', 'GV13229', 'NN', 10, 'Đang mở'),
('NN.9.4.2', 'Khóa giao tiếp NN.9.4.2', 'GV13229', 'NN', 10, 'Sắp mở'),
('S.9.1.4', 'Khóa Starter S.9.1.4', 'GV90804', 'S', 10, 'Đã đóng'),
('S.9.3.1', 'Khóa Starter S.9.3.1', 'GV21950', 'S', 10, 'Đang mở'),
('S.9.3.2', 'Khóa Starter S.9.3.2', 'GV76142', 'S', 10, 'Sắp mở'),
('TC.9.2.4', 'Khóa 4 kỹ năng TC.9.2.4', 'GV21950', 'TC', 10, 'Đã đóng'),
('TC.9.3.1', 'Khóa 4 kỹ năng TC.9.3.1', 'GV76142', 'TC', 10, 'Đang mở'),
('TC.9.4.2', 'Khóa 4 kỹ năng TC.9.4.2', 'GV78583', 'TC', 10, 'Sắp mở');

-- --------------------------------------------------------

--
-- Table structure for table `luonggv`
--

CREATE TABLE `luonggv` (
  `magv` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `luongcb` int(11) DEFAULT NULL,
  `ngaycong` int(11) DEFAULT NULL,
  `trocap` int(11) DEFAULT NULL,
  `thuong` int(11) DEFAULT NULL,
  `traluong` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `luonggv`
--

INSERT INTO `luonggv` (`magv`, `luongcb`, `ngaycong`, `trocap`, `thuong`, `traluong`) VALUES
('GV13229', 10000000, 30, 500000, 100000, 'Đã trả'),
('GV21950', 10000000, 30, 1000000, 1000000, 'Chưa trả'),
('GV62250', 11000000, 26, 1000000, 800000, 'Chưa trả'),
('GV76142', 9000000, 28, 1000000, 1000000, 'Chưa trả'),
('GV78583', 9000000, 27, 1000000, 1000000, 'Chưa trả'),
('GV90804', 15000000, 30, 1000000, 100000, 'Chưa trả');

-- --------------------------------------------------------

--
-- Table structure for table `phuhuynh`
--

CREATE TABLE `phuhuynh` (
  `maph` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `mahs` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `tenph` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `diachi` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `phuhuynh`
--

INSERT INTO `phuhuynh` (`maph`, `mahs`, `tenph`, `sdt`, `email`, `diachi`) VALUES
('PH11276', 'HS60356', 'Lý Văn Sáng', '0990337485', 'sanglv1@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH14561', 'HS53472', 'Nguyễn Hoàng Hải', '0923830783', 'hainh@gmail.com', 'Hà Đông, Hà Nội'),
('PH23681', 'HS82256', 'Lý Văn Ba', '0973817185', 'balv@gmail.com', 'Hà Đông, Hà Nội'),
('PH24986', 'HS77552', 'Lý Thị Trúc', '0932161715', 'truclt@gmail.com', 'Hà Đông, Hà Nội'),
('PH35636', 'HS61507', 'Đinh Thị Thảo', '0996083742', 'thaodt@gmail.com', 'Hà Đông, Hà Nội'),
('PH37543', 'HS70111', 'Lý Thị Thủy', '0971262991', 'thuylt@gmail.com', 'Hà Đông, Hà Nội'),
('PH38481', 'HS74183', 'Nguyễn Minh Hiếu', '0911343338', 'hieunm@gmail.com', 'Hà Đông, Hà Nội'),
('PH43315', 'HS23879', 'Lâm Văn Sáng', '0956069897', 'sanglv@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH43817', 'HS27050', 'Nguyễn Hưng Kiên', '0971992140', 'kiennh@gmail.com', 'Hà Đông, Hà Nội'),
('PH47753', 'HS98366', 'Đặng Hoàng Hùng', '0989812056', 'hungdh@gmail.com', 'Hà Đông, Hà Nội'),
('PH53873', 'HS42955', 'Hoàng Văn Hùng', '0376060361', 'hunghv@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH58265', 'HS23640', 'Hoàng Văn Sáng', '0936985567', 'sanghv12@gmail.com', 'Hà Đông, Hà Nội'),
('PH58580', 'HS39737', 'Nguyễn Văn Hành', '0917002393', 'hanhnv@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH59052', 'HS81285', 'Phan Quân', '0899216652', 'quanp@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH61715', 'HS30202', 'Hoàng Văn Mạnh', '0990749913', 'manhhv@gmail.com', 'Hà Đông, Hà Nội'),
('PH62263', 'HS35335', 'Giáp Văn Thọ', '0986629327', 'thogv@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH65209', 'HS42879', 'Lý Thị Hằng', '0934806435', 'hanglt@gmail.com', 'Hà Đông, Hà Nội'),
('PH68787', 'HS85687', 'Lâm Thị Như', '0322119863', 'nhult@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH72471', 'HS73046', 'Đàm Văn Minh', '0927450108', 'minhdv@gmail.com', 'Hà Đông, Hà Nội'),
('PH77913', 'HS65356', 'Nguyễn Văn Bảo', '0960604536', 'baonv@gmail.com', 'Hà Đông, Hà Nội'),
('PH78827', 'HS88077', 'Nguyễn Minh Hải', '0333031318', 'hainm@gmail.com', 'Hà Đông, Hà Nội'),
('PH80444', 'HS67336', 'Vũ Hoàng Yến', '0949615387', 'yenvh@gmail.com', 'Hà Đông, Hà Nội'),
('PH82109', 'HS42192', 'Đinh Văn Hùng', '0941558415', 'hungdv12@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH82872', 'HS50629', 'Huỳnh Hiểu Minh', '0843580671', 'minhhh@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH83132', 'HS75379', 'Phùng Văn Hùng', '0990233978', 'hungpv@gmail.com', 'Hà Đông, Hà Nội'),
('PH89214', 'HS44984', 'Nguyễn Văn Bách', '0965867046', 'bachnv@gmail.com', 'Hà Đông, Hà Nội'),
('PH89957', 'HS67488', 'Lê Văn Trường', '0933858791', 'truonglv@gmail.com', 'Thanh Xuân, Hà Nội'),
('PH96929', 'HS29863', 'Dương Thái Hoàng', '0933307947', 'hoangdt@gmail.com', 'Hà Đông, Hà Nội');

-- --------------------------------------------------------

--
-- Table structure for table `quangcao`
--

CREATE TABLE `quangcao` (
  `id` int(11) NOT NULL,
  `anh` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `quangcao`
--

INSERT INTO `quangcao` (`id`, `anh`) VALUES
(3, 'anhnen.jpg'),
(4, 'bg1.jpg'),
(5, 'posterTTTA1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `usergv`
--

CREATE TABLE `usergv` (
  `magv` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usergv`
--

INSERT INTO `usergv` (`magv`, `username`, `password`) VALUES
('GV13229', 'GV13229', '0888899999'),
('GV21950', 'GV21950', '0887651234'),
('GV62250', 'GV62250', '0987654321'),
('GV76142', 'GV76142', '0999999999'),
('GV78583', 'GV78583', '0988886666'),
('GV90804', 'GV90804', '0888888888');

-- --------------------------------------------------------

--
-- Table structure for table `userhs`
--

CREATE TABLE `userhs` (
  `mahs` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `userhs`
--

INSERT INTO `userhs` (`mahs`, `username`, `password`) VALUES
('HS17160', 'HS17160', '0995330736'),
('HS23640', 'HS23640', '0927749439'),
('HS23879', 'HS23879', '0311189634'),
('HS24215', 'HS24215', '0344440380'),
('HS27050', 'HS27050', '0369645195'),
('HS29863', 'HS29863', '0934912642'),
('HS30202', 'HS30202', '0932566193'),
('HS32638', 'HS32638', '0988159958'),
('HS35335', 'HS35335', '0951059993'),
('HS35994', 'HS35994', '0340454059'),
('HS39108', 'HS39108', '0385963734'),
('HS39737', 'HS39737', '0956257573'),
('HS41091', 'HS41091', '0962266504'),
('HS42192', 'HS42192', '0980897704'),
('HS42879', 'HS42879', '0385581689'),
('HS42955', 'HS42955', '0392965691'),
('HS44984', 'HS44984', '0312798012'),
('HS49492', 'HS49492', '0967841405'),
('HS49690', 'HS49690', '0329937516'),
('HS50629', 'HS50629', '0993624566'),
('HS53472', 'HS53472', '0944699456'),
('HS58013', 'HS58013', '0988454646'),
('HS60356', 'HS60356', '0976545318'),
('HS61507', 'HS61507', '0999919119'),
('HS63704', 'HS63704', '0817204954'),
('HS64925', 'HS64925', '0347906523'),
('HS65356', 'HS65356', '0312173458'),
('HS67046', 'HS67046', '0964532621'),
('HS67336', 'HS67336', '0995548382'),
('HS67488', 'HS67488', '0918531264'),
('HS70111', 'HS70111', '0951992022'),
('HS71223', 'HS71223', '0962864778'),
('HS72162', 'HS72162', '0952842162'),
('HS73046', 'HS73046', '0926262975'),
('HS73413', 'HS73413', '0950268032'),
('HS74183', 'HS74183', '0977309640'),
('HS75379', 'HS75379', '0383973333'),
('HS77552', 'HS77552', '0966633257'),
('HS80015', 'HS80015', '0349172360'),
('HS81285', 'HS81285', '0956911705'),
('HS82256', 'HS82256', '0391349400'),
('HS84353', 'HS84353', '0986738270'),
('HS85316', 'HS85316', '0944440380'),
('HS85687', 'HS85687', '0949123211'),
('HS85788', 'HS85788', '0384873116'),
('HS88077', 'HS88077', '0392323456'),
('HS95803', 'HS95803', '0982346656'),
('HS98366', 'HS98366', '0932022646');

-- --------------------------------------------------------

--
-- Table structure for table `userph`
--

CREATE TABLE `userph` (
  `maph` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `userph`
--

INSERT INTO `userph` (`maph`, `username`, `password`) VALUES
('PH11276', 'PH11276', '0990337485'),
('PH14561', 'PH14561', '0923830783'),
('PH23681', 'PH23681', '0973817185'),
('PH24986', 'PH24986', '0932161715'),
('PH35636', 'PH35636', '0996083742'),
('PH37543', 'PH37543', '0971262991'),
('PH38481', 'PH38481', '0911343338'),
('PH43315', 'PH43315', '0956069897'),
('PH43817', 'PH43817', '0971992140'),
('PH47753', 'PH47753', '0989812056'),
('PH53873', 'PH53873', '0376060361'),
('PH58265', 'PH58265', '0936985567'),
('PH58580', 'PH58580', '0917002393'),
('PH59052', 'PH59052', '0899216652'),
('PH61715', 'PH61715', '0990749913'),
('PH62263', 'PH62263', '0986629327'),
('PH65209', 'PH65209', '0934806435'),
('PH68787', 'PH68787', '0322119863'),
('PH72471', 'PH72471', '0927450108'),
('PH77913', 'PH77913', '0960604536'),
('PH78827', 'PH78827', '0333031318'),
('PH80444', 'PH80444', '0949615387'),
('PH82109', 'PH82109', '0941558415'),
('PH82872', 'PH82872', '0843580671'),
('PH83132', 'PH83132', '0990233978'),
('PH89214', 'PH89214', '0965867046'),
('PH89957', 'PH89957', '0933858791'),
('PH96929', 'PH96929', '0933307947');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diemdanh`
--
ALTER TABLE `diemdanh`
  ADD PRIMARY KEY (`mahs`,`malop`),
  ADD KEY `diemdanh_ibfk_2` (`malop`);

--
-- Indexes for table `dkyhoc`
--
ALTER TABLE `dkyhoc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dkylop`
--
ALTER TABLE `dkylop`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dkylop_ibfk_1` (`malop`);

--
-- Indexes for table `giaovien`
--
ALTER TABLE `giaovien`
  ADD PRIMARY KEY (`magv`);

--
-- Indexes for table `hocphi`
--
ALTER TABLE `hocphi`
  ADD PRIMARY KEY (`makhoa`);

--
-- Indexes for table `hocphi_hocsinh`
--
ALTER TABLE `hocphi_hocsinh`
  ADD PRIMARY KEY (`malop`,`mahs`),
  ADD KEY `hocphi_hocsinh_ibfk_1` (`makhoa`),
  ADD KEY `hocphi_hocsinh_ibfk_3` (`mahs`);

--
-- Indexes for table `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD PRIMARY KEY (`mahs`,`malop`),
  ADD KEY `hocsinh_fk` (`malop`);

--
-- Indexes for table `khoa`
--
ALTER TABLE `khoa`
  ADD PRIMARY KEY (`makhoa`);

--
-- Indexes for table `lichhoc`
--
ALTER TABLE `lichhoc`
  ADD PRIMARY KEY (`malop`);

--
-- Indexes for table `lophoc`
--
ALTER TABLE `lophoc`
  ADD PRIMARY KEY (`malop`,`magv`),
  ADD KEY `giaovien_fk` (`magv`);

--
-- Indexes for table `luonggv`
--
ALTER TABLE `luonggv`
  ADD PRIMARY KEY (`magv`);

--
-- Indexes for table `phuhuynh`
--
ALTER TABLE `phuhuynh`
  ADD PRIMARY KEY (`maph`,`mahs`),
  ADD KEY `phuhuynh_ibfk_1` (`mahs`);

--
-- Indexes for table `quangcao`
--
ALTER TABLE `quangcao`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usergv`
--
ALTER TABLE `usergv`
  ADD PRIMARY KEY (`magv`);

--
-- Indexes for table `userhs`
--
ALTER TABLE `userhs`
  ADD PRIMARY KEY (`mahs`);

--
-- Indexes for table `userph`
--
ALTER TABLE `userph`
  ADD PRIMARY KEY (`maph`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dkyhoc`
--
ALTER TABLE `dkyhoc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dkylop`
--
ALTER TABLE `dkylop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `quangcao`
--
ALTER TABLE `quangcao`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diemdanh`
--
ALTER TABLE `diemdanh`
  ADD CONSTRAINT `diemdanh_ibfk_1` FOREIGN KEY (`mahs`) REFERENCES `hocsinh` (`mahs`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `diemdanh_ibfk_2` FOREIGN KEY (`malop`) REFERENCES `lophoc` (`malop`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dkylop`
--
ALTER TABLE `dkylop`
  ADD CONSTRAINT `dkylop_ibfk_1` FOREIGN KEY (`malop`) REFERENCES `lophoc` (`malop`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hocphi`
--
ALTER TABLE `hocphi`
  ADD CONSTRAINT `hocphi_ibfk_1` FOREIGN KEY (`makhoa`) REFERENCES `khoa` (`makhoa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hocphi_hocsinh`
--
ALTER TABLE `hocphi_hocsinh`
  ADD CONSTRAINT `hocphi_hocsinh_ibfk_1` FOREIGN KEY (`makhoa`) REFERENCES `hocphi` (`makhoa`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hocphi_hocsinh_ibfk_2` FOREIGN KEY (`malop`) REFERENCES `lophoc` (`malop`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `hocphi_hocsinh_ibfk_3` FOREIGN KEY (`mahs`) REFERENCES `hocsinh` (`mahs`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hocsinh`
--
ALTER TABLE `hocsinh`
  ADD CONSTRAINT `hocsinh_fk` FOREIGN KEY (`malop`) REFERENCES `lophoc` (`malop`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lichhoc`
--
ALTER TABLE `lichhoc`
  ADD CONSTRAINT `lophoc_fk` FOREIGN KEY (`malop`) REFERENCES `lophoc` (`malop`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lophoc`
--
ALTER TABLE `lophoc`
  ADD CONSTRAINT `giaovien_fk` FOREIGN KEY (`magv`) REFERENCES `giaovien` (`magv`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `luonggv`
--
ALTER TABLE `luonggv`
  ADD CONSTRAINT `luonggv_ibfk_1` FOREIGN KEY (`magv`) REFERENCES `giaovien` (`magv`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `phuhuynh`
--
ALTER TABLE `phuhuynh`
  ADD CONSTRAINT `phuhuynh_ibfk_1` FOREIGN KEY (`mahs`) REFERENCES `hocsinh` (`mahs`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usergv`
--
ALTER TABLE `usergv`
  ADD CONSTRAINT `usergv_ibfk_1` FOREIGN KEY (`magv`) REFERENCES `giaovien` (`magv`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userhs`
--
ALTER TABLE `userhs`
  ADD CONSTRAINT `userhs_ibfk_1` FOREIGN KEY (`mahs`) REFERENCES `hocsinh` (`mahs`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `userph`
--
ALTER TABLE `userph`
  ADD CONSTRAINT `userph_ibfk_1` FOREIGN KEY (`maph`) REFERENCES `phuhuynh` (`maph`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
